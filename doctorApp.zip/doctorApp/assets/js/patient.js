$(function () {
  
  $(".viewData").on("click", function () {
    var type = $(this).data("type");
    var id = $(this).data("id");
    var is_status = '';
    
    //console.log('32423');
    $.ajax({
      url: "http://localhost/doctorApp/admin/patients/allDetails",
      type: "post",
      data: { 'id': id },
        //  console.log('del_id');

      // data: {'is_status':is_status},
      dataType: 'json',
      success: function (response) {
        
        //console.log(response);
        // You will get response from your PHP page (what you echo or print)
        if (response.data.is_status == '0') {
          is_status = '<span class="label label-sm label-warning ">Not Attended</span>';

        } else {
          is_status = '<span class="label label-sm label-success">Attended</span>';
        }
        Swal.fire({
          title: "<strong><u>Patient Details</u></strong>",
          html:
            '<div class="modal-dialog modal-dialog-centered" role="document"><div class="modal-content"><div class="modal-body"><div class="row"><div class="col-md-12"><div class="form-group">' + is_status + '</div><div class="row"><div class="col-md-12"><div class="form-group"><label>Patient Description</label><textarea  name="p_description" placeholder="Enter Details" class="form-control" disabled="">' + response.data.patient_description + '</textarea></div></div></div><div class="row"><div class="col-md-12"><div class="form-group"><label>Doctor Description</label><textarea id="details_' + response.data.id + '" name="d_description" placeholder="Enter Details" class="form-control">' + response.data.doctor_description + '</textarea></div></div></div><button type="button" name="submit" value="submit" class="btn btn-round btn-primary" onclick="updateData(' + response.data.id + ')">Add</button></div></div></div>',
          showCancelButton: false,
          showConfirmButton: false,
        });

      },
      error: function (jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);
      }
    });
  });
  


});
function updateData(id) {

  var desc = $("#details_" + id).val();
  if (desc != '') {
    //alert(id);
    //updated
    $.ajax({
      url: "http://localhost/doctorApp/admin/patients/upDetails",
      type: "post",
      data: { 'id': id, 'desc': desc },
      // data: {'is_status':is_status},
      dataType: 'json',
      success: function (response) {
        //console.log(response);
        // You will get response from your PHP page (what you echo or print)
        if (response.status == 200) {
          location.reload();
        }

      },
      error: function (jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);
      }
    });
  } else {
    alert('desc add');
  }
}
// $(function (){
//   $(".aboutDetails").on("click", function () {



//   });
// });
$(".aboutDetails").on("click", function () {
  var id = $(this).data("id");
  
   //console.log(id);
  $.ajax({
    url: "http://localhost/doctorApp/admin/patients/aboutDetails",
    type: "post",
    data: {'patient_id': id,'name': id},
    dataType: 'json',

    success: function (response) {
   
     var tblData = '<table class="table table-bordered"><tr><th>Sr No.</th><th>Doctor Name</th><th>Appointment Date</th><th>Patient Description</th><th>Doctor Description</th><th>Status</th></tr>';
     // var sr=0;
     
      $.each(response.data, function( index, value ) {
       var doc = doctor_name(value.doctor_id);
        var no = index + 1;
        var is_status = '';
        if (value.is_status == '0') {
          // console.log(response.data.is_status);
          is_status = '<span class="label label-sm label-warning ">Not Attended</span>';
    
        } else {
          is_status = '<span class="label label-sm label-success">Attended</span>';
        }
        tblData +='<tr><td>'+no+'</td><td>'+doc.name+'</td><td>'+value.date_time+'</td><td>'+value.patient_description+'</td><td>'+value.doctor_description+'</td><td>' + is_status + '</td></tr>';
      });
      tblData +='</table>';
      Swal.fire({
        title: "All Details",
        html:
          '<div class="row"><button onclick="window.print()" class="btn btn-default prbtn"><span><i class="fa fa-print"></i>Print</span></button></div><div class="table-responsive"><table class="table table-bordered"><tr><td>Patient Name:</td><td>' + response.p_data.name + '</td></tr><tr><td>Mobile No:</td><td>' + response.p_data.mobile_no + '</td></tr><tr><td>Age:</td><td>' + response.p_data.age + '</td></tr></table>'+tblData+'</div>',
        customClass: 'swal-wide',
        showCancelButton: false,
        showConfirmButton: false,
      });
    },
      error: function (jqXHR, textStatus, errorThrown) {
      console.log(textStatus, errorThrown);
    }
     
  });
});
function doctor_name(id){
  var result = '';
  $.ajax({
    url: "http://localhost/doctorApp/admin/patients/doctorDetails",
    type: "post",
    data: {'id': id},
    dataType: 'json',
    async: false,
    success: function (response) {
      result = response.data;
        }
      });
    return result; 
}
$(".bookDetails").on("click", function () {
  var type = $(this).data("type");
  var id = $(this).data("id");
  
  
    
  $.ajax({
    url: "http://localhost/doctorApp/admin/patients/bookappointment",
    type: "post",
    data: {'id': id},
    dataType: 'json',
    
    success: function (response) {
      //  console.log(id);
      
      // console.log(response);
      Swal.fire({
        title: "Appointment Form",
        
        html:
        '<form action="http://localhost/doctorApp/admin/patients/appointment_ajax" method="post"><div class="row"><table class="table display product-overview mb-30"><input type="hidden" name="patient_id" value="'+response.patientData.id +'"><tr><th>Name</th><td>'+response.patientData.name +'</td><th>Mobile No</th><td>'+response.patientData.mobile_no +'</td></tr><tr><th>Doctor Name</th><td><select name="doctor_id"><option>select doctor</option>'+response.doctorLists+'</select></td><th>Date&Time</th><td><input type="datetime-local" name="date_time"/></tr><tr><th>Patient Description</th><td><textarea name="patient_description" class="form-control"></textarea></tr></table></div><button type="submit" name="submit" value="submit" class="btn-success" >Save Information</button></form>',
        
        customClass: 'swal-wide',
        showCancelButton: false,
        showConfirmButton: false,
     
      });
      //  console.log(response);
    },
    
      error: function (jqXHR, textStatus, errorThrown) {
      console.log(textStatus, errorThrown);
    }
     
  });
});


// $(function () {
//   $(".doctorsData").on("click", function () {
//     var type = $(this).data("type");
//     var id = $(this).data("id");
//     var is_status = '';
//     //console.log('32423');
//     $.ajax({
//       url: "http://localhost/patientApp/admin/patients/aboutDetails",
//       type: "post",
//       data: { 'id': id },
//         //  console.log('del_id');

//       // data: {'is_status':is_status},
//       dataType: 'json',
//       success: function (response) {
        
//         //console.log(response);
//         // You will get response from your PHP page (what you echo or print)
//         if (response.data.is_status == '0') {
//           is_status = '<span class="label label-sm label-warning ">Not Attended</span>';

//         } else {
//           is_status = '<span class="label label-sm label-success">Attended</span>';
//         }
//         Swal.fire({
//           title: "<strong><u>Patient Details</u></strong>",
//           html:
//             '<div class="modal-dialog modal-dialog-centered" role="document"><div class="modal-content"><div class="modal-body"><div class="row"><div class="col-md-12"><div class="form-group">' + is_status + '</div><div class="row"><div class="col-md-12"><div class="form-group"><label>Patient Description</label><textarea  name="p_description" placeholder="Enter Details" class="form-control" disabled="">' + response.data.patient_description + '</textarea></div></div></div><div class="row"><div class="col-md-12"><div class="form-group"><label>Doctor Description</label><textarea id="details_' + response.data.id + '" name="d_description" placeholder="Enter Details" class="form-control">' + response.data.doctor_description + '</textarea></div></div></div><button type="button" name="submit" value="submit" class="btn btn-round btn-primary" onclick="updateData(' + response.data.id + ')">Add</button></div></div></div>',
//           showCancelButton: false,
//           showConfirmButton: false,
//         });

//       },
//       error: function (jqXHR, textStatus, errorThrown) {
//         console.log(textStatus, errorThrown);
//       }
//     });
//   });
// });
 
// for doctor view All Details

$(".doctordetails").on("click", function () {
  var id = $(this).data("id");
  
  //  console.log(doctordetails);
   $.ajax({
    url: "http://localhost/doctorApp/admin/doctors/d_Details",
    type: "post",
    data: {'doctor_id': id,'name': id},
    dataType: 'json',

    success: function (response) {
   
     var tblData = '<table class="table table-bordered"><tr><th>Sr No.</th><th>Doctor Name</th><th>Appointment Date</th><th>Patient Description</th><th>Doctor Description</th><th>Status</th></tr>';
     // var sr=0;
     
      $.each(response.data, function( index, value ) {
        var pat = patient_name(value.patient_id);
        var no = index + 1;
        var is_status = '';
        if (value.is_status == '0') {
          // console.log(response.data.is_status);
          is_status = '<span class="label label-sm label-warning ">Not Attended</span>';
    
        } else {
          is_status = '<span class="label label-sm label-success">Attended</span>';
        }
        tblData +='<tr><td>'+no+'</td><td>'+pat.name+'</td><td>'+value.date_time+'</td><td>'+value.patient_description+'</td><td>'+value.doctor_description+'</td><td>' + is_status + '</td></tr>';
      });
      tblData +='</table>';
      Swal.fire({
        title: "All Details",
        html:
          '<div class="row"><button onclick="window.print()" class="btn btn-default prbtn"><span><i class="fa fa-print"></i>Print</span></button></div><div class="table-responsive"><table class="table table-bordered"><tr><td>Patient Name:</td><td>' + response.d_data.name + '</td></tr><tr><td>Mobile No:</td><td>' + response.d_data.mobile_no + '</td></tr><tr><td>Age:</td><td>' + response.d_data.age + '</td></tr></table>'+tblData+'</div>',
         
        customClass: 'swal-wide',
        showCancelButton: false,
        showConfirmButton: false,
      });
    },
      error: function (jqXHR, textStatus, errorThrown) {
      console.log(textStatus, errorThrown);
    }
     
  });
});
function patient_name(id){
  var result = '';
  $.ajax({
    url: "http://localhost/doctorApp/admin/patients/patientDetails",
    type: "post",
    data: {'id': id},
    dataType: 'json',
    async: false,
    success: function (response) {
      result = response.data;
        }
      });
    return result; 
}



    