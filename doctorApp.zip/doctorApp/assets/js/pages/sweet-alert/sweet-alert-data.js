$(function () {
  $(".btn-sweetalert button").on("click", function () {
    var type = $(this).data("type");
    var id = $(this).data("id");
    if (type === "dialog1") {
      showDialog1(id);
    } else if (type === "dialog2") {
      showDialog2();
    } else if (type === "dialog3") {
      showDialog3();
    } else if (type === "dialog4") {
      showDialog4();
    } else if (type === "dialog5") {
      showDialog5();
    } else if (type === "dialog6") {
      showDialog6();
    } else if (type === "dialog7") {
      showDialog7();
    } else if (type === "dialog8") {
      showDialog8();
    } else if (type === "dialog9") {
      showDialog9();
    } else if (type === "dialog10") {
      showDialog10();
    }
  });
});


function showDialog1(id) {
  
  $.ajax({
    url: "http://localhost/doctorApp/admin/patients/allDetails",
    type: "post",
    data: {'id':id},
    dataType  : 'json',
    success: function (response) {
      console.log(response.data.patient_description);
       // You will get response from your PHP page (what you echo or print)
       Swal.fire({
        title: "<strong><u>Patient Details</u></strong>",
        html:
          '<div class="modal-dialog modal-dialog-centered" role="document"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="addEventTitle">Add Patient</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><form class=""><input type="hidden" id="id" name="id"><div class="row"><div class="col-md-12"><div class="form-group"><div class="input-group"><input type="text" class="form-control" placeholder="Patient Name" name="title" id="title"></div></div></div></div><div class="row"><div class="col-md-12 mb-4"><label>Status</label><select class="form-select" id="categorySelect"><option id="work" value="fc-event-success">Attand</option><option id="personal" value="fc-event-warning">Not Attand</option></select></div></div><div class="row"><div class="col-md-12"><div class="form-group"><label>Patient Description</label><textarea id="eventDetails" name="eventDetails" placeholder="Enter Details" class="form-control">'+response.data.patient_description+'</textarea></div></div></div><div class="row"><div class="col-md-12"><div class="form-group"><label>Doctor Description</label><textarea id="eventDetails" name="eventDetails" placeholder="Enter Details" class="form-control"></textarea></div></div></div><div class="modal-footer bg-whitesmoke pr-0"><button type="button" class="btn btn-round btn-primary" id="add-event">Add Event</button><button type="button" class="btn btn-round btn-primary" id="edit-event">Edit Event</button><button type="button" id="close" class="btn btn-danger" data-bs-dismiss="modal">Close</button></div></form></div></div></div>',
          showCancelButton: false,
          showConfirmButton: false
      });
    },
    error: function(jqXHR, textStatus, errorThrown) {
       console.log(textStatus, errorThrown);
    }
  });
 
}


function showDialog2() {
  Swal.fire("The Internet?", "That thing is still around?", "question");
}

function showDialog3() {
  Swal.fire({
    icon: "error",
    title: "Oops...",
    text: "Something went wrong!",
    footer: "<a href>Why do I have this issue?</a>",
  });
}

function showDialog4() {
  Swal.fire({
    imageUrl: "https://placeholder.pics/svg/300x1500",
    imageHeight: 1500,
    imageAlt: "A tall image",
  });
}

function showDialog5() {
  Swal.fire({
    title: "<strong>HTML <u>example</u></strong>",
    icon: "info",
    html:
      "You can use <b>bold text</b>, " +
      '<a href="//sweetalert2.github.io">links</a> ' +
      "and other HTML tags",
    showCloseButton: true,
    showCancelButton: true,
    focusConfirm: false,
    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Great!',
    confirmButtonAriaLabel: "Thumbs up, great!",
    cancelButtonText: '<i class="fa fa-thumbs-down"></i>',
    cancelButtonAriaLabel: "Thumbs down",
  });
}

function showDialog6() {
  Swal.fire({
    position: "bottom-end",
    icon: "success",
    title: "Your work has been saved",
    showConfirmButton: false,
    timer: 1500,
  });
}

function showDialog7() {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.value) {
      Swal.fire("Deleted!", "Your file has been deleted.", "success");
    }
  });
}

function showDialog8() {
  Swal.fire({
    title: "Sweet!",
    text: "Modal with a custom image.",
    imageUrl: "https://unsplash.it/400/200",
    imageWidth: 400,
    imageHeight: 200,
    imageAlt: "Custom image",
  });
}

function showDialog9() {
  let timerInterval;
  Swal.fire({
    title: "Auto close alert!",
    html: "I will close in <b></b> milliseconds.",
    timer: 2000,
    timerProgressBar: true,
    onBeforeOpen: () => {
      Swal.showLoading();
      timerInterval = setInterval(() => {
        const content = Swal.getContent();
        if (content) {
          const b = content.querySelector("b");
          if (b) {
            b.textContent = Swal.getTimerLeft();
          }
        }
      }, 100);
    },
    onClose: () => {
      clearInterval(timerInterval);
    },
  }).then((result) => {
    /* Read more about handling dismissals below */
    if (result.dismiss === Swal.DismissReason.timer) {
      console.log("I was closed by the timer");
    }
  });
}

function showDialog10() {
  Swal.fire({
    title: "هل تريد الاستمرار؟",
    icon: "question",
    iconHtml: "؟",
    confirmButtonText: "نعم",
    cancelButtonText: "لا",
    showCancelButton: true,
    showCloseButton: true,
  });
}
