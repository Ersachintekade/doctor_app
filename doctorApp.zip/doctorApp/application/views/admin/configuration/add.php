<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>
<!-- start page container -->
<div class="page-container">
    <?php $this->load->view('layout/left_menu.php');?>
    <!-- start page content -->
    <form action="<?php echo site_url('admin/configuration/add');?>" method="post" enctype="multipart/form-data">
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="page-bar">
                    <div class="page-title-breadcrumb">
                        <div class=" pull-left">
                            <div class="page-title">
                            <?php echo $this->lang->line('clinic_details') ?>
                            </div>
                        </div>
                        <ol class="breadcrumb page-breadcrumb pull-right">
                            <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                                    href="<?php echo site_url('admin/users/index'); ?>">
                                    <?php echo $this->lang->line('home') ?>
                                </a>&nbsp;<i class="fa fa-angle-right"></i>
                            </li>
                            <li class="active">
                            <?php echo $this->lang->line('clinic_details') ?>
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- start widget -->
                <!-- end widget -->
                <div class="row">
                    <div class="col-sm-12">
                        <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success !</strong>
                            <?= $this->session->flashdata('success_msg');?>
                        </div>
                        <?php } ?>
                        <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error !</strong>
                            <?= $this->session->flashdata('error_msg');?>
                        </div>
                        <?php } ?>
                        <div class="card-box">
                            <div class="card-head">
                                <header class="info-box-title">
                                <?php echo $this->lang->line('clinic_details') ?>
                                </header>
                                <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                                    data-mdl-for="panel-button">
                                    <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                                    </li>
                                    <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                                    </li>
                                    <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                                        here</li>
                                </ul>
                            </div>
                            <div class="card-body row">
                            
											<!-- Contact form -->
											<div class="col-sm-6">
                                                    
                                                    <div class="form-group">
                                                        <label for="error"><?php echo $this->lang->line('clinic_name') ?></label>
                                                            <input class="form-control" id="clinic_name" name="clinic_name"
                                                                placeholder="<?php echo $this->lang->line('enter_clinicname') ?>" type="text" value="<?php echo set_value('clinic_name');?>">
                                                            <label for="error" class="error"><?= form_error('clinic_name'); ?></label>
                                                    </div>
                                                    <div class="form-group">
                                                    <div>
                                                        <label for="Image"><?php echo $this->lang->line('image') ?></label>
                                                        <input type="file" class="form-control" class="custom-file-input" name="image" id="image" value="upload" accept="image/jpeg, image/png, image/jpg">
                                                        <img id="image">
                                                    </div>
                                                    <label for="error" class="error"><?= form_error('image'); ?></label>
                                                    </div>
													<!-- /Form-name -->
													<div class="form-group">
                                                    <label><?php echo $this->lang->line('owner_name') ?></label>
														<input class="form-control" id="owner_name" name="owner_name"
															type="text"  placeholder="<?php echo $this->lang->line('enter_ownername') ?>" value="<?php echo set_value('owner_name');?>">
                                                        <label for="error" class="error"><?= form_error('owner_name'); ?></label>
													</div>
                                                    <div class="form-group">
                                                    <label><?php echo $this->lang->line('mobile_no') ?></label>
														<input class="form-control" id="mobile_no" name="mobile_no"
															type="number" placeholder="<?php echo $this->lang->line('your_mobileno') ?>" value="<?php echo set_value('mobile_no'); ?>" >
                                                        <label for="error" class="error"><?= form_error('mobile_no'); ?></label>
													</div>
                                                    <div class="form-group">
                                                    <label><?php echo $this->lang->line('email_id') ?></label>
														<input class="form-control" id="email_id" name="email_id"
															type="email" placeholder="<?php echo $this->lang->line('your_emailid') ?>" value="<?php echo set_value('email_id'); ?>" >
                                                        <label for="error" class="error"><?= form_error('email_id'); ?></label>
													</div>
													<!-- /Form-email -->
													<div class="form-group">
                                                    <label><?php echo $this->lang->line('clinic_address') ?></label>
														<textarea class="form-control" id="address" name="address"
															rows="5" placeholder="<?php echo $this->lang->line('pls_enteraddress') ?>" value="<?php echo set_value('address'); ?>"></textarea>
                                                        <label for="error" class="error"><?= form_error('address'); ?></label>
													</div>
                                                    
													<!-- /Form Msg -->
													<div class="row">
														<div class="col-12">
															<div class="">
                                                            <div class="col-lg-12 p-t-20">
        <button type="submit" name="submit" value="submit"
            class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 m-r-20 btn-circle btn-primary"><?php echo $this->lang->line('submit') ?></button>
            <a href="<?php echo site_url('admin/users/index');?>"><button type="button" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 btn-circle btn-danger"><?php echo $this->lang->line('cancel') ?></button></a>
    </div>
															</div>
														</div> 
													</div> 
											</div>
											<!-- end col -->
										</div> 
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!-- </div> -->
<!-- end page content -->
</form>
</div>
<!-- end page container -->

<?php $this->load->view('layout/footer.php');?>