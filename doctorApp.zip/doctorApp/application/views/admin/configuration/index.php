<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
<!-- start page container -->
<div class="page-container">
<?php $this->load->view('layout/left_menu.php');?>   
<!-- start page content -->
    <div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title"><?php echo $this->lang->line('hospital_details') ?></div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                            href="<?php echo site_url('admin/users/index'); ?>"><?php echo $this->lang->line("home") ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active"><?php echo $this->lang->line('hospital_details') ?></li>
                </ol>
            </div>
        </div>
    <!-- start widget -->
    <div class="row">
    <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
        <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
        </div>
    <?php } ?>
    <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
        <div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
        </div>
    <?php } ?>
    </div>
 <!-- end widget -->
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card card-box">
                <div class="card-head">
                    <header><?php echo $this->lang->line('hospital_details') ?></header>
                    <div class="tools">
                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                    </div>
                </div>
    <div class="card-body no-padding height-9">
        <div class="row table-padding">
            <div class="col-md-6 col-sm-6 col-6">
                <div class="btn-group">
                <a href="<?php echo site_url('admin/doctors/add');?>" id="addRow" class="btn btn-info">
                <?php echo $this->lang->line("add_new") ?><i class="fa fa-plus"></i>
                    </a>
                </div>
            </div>
    <div class="col-md-6 col-sm-6 col-6">
        <div class="btn-group pull-right">
            <a class="btn deepPink-bgcolor  btn-outline dropdown-toggle"
                data-bs-toggle="dropdown"><?php echo $this->lang->line("tools") ?>
                <i class="fa fa-angle-down"></i>
            </a>
            <ul class="dropdown-menu pull-right">
                <li>
                    <a href="javascript:;">
                        <i class="fa fa-print"></i><?php echo $this->lang->line("print") ?></a>
                </li>
                <li>
                    <a href="javascript:;">
                        <i class="fa fa-file-pdf-o"></i><?php echo $this->lang->line("saveas_pdf") ?></a>
                </li>
                <li>
                    <a href="javascript:;">
                        <i class="fa fa-file-excel-o"></i><?php echo $this->lang->line("export_excel") ?></a>
                </li>
            </ul>
        </div>
    </div>
</div>
    <div class="table-responsive">
        <table
            class="table table-striped table-bordered table-hover table-checkable order-column"
            id="example4">
            <thead>
                <tr>
                    <th class="center"><?php echo $this->lang->line('sr_no') ?></th>
                    <th class="center"><?php echo $this->lang->line('clinic_name') ?></th>
                    <th class="center"><?php echo $this->lang->line('image') ?></th>
                    <th class="center"><?php echo $this->lang->line('owner_name') ?></th>
                    <th class="center"><?php echo $this->lang->line('mobile_no') ?></th>
                    <th class="center"><?php echo $this->lang->line('email_id') ?></th>
                    <th class="center"><?php echo $this->lang->line('address') ?></th>
                    <th class="center"><?php echo $this->lang->line('action') ?></th>
                </tr>
            </thead>
        <tbody>
        <?php 
        if(!empty($configuration))
        {
            $sr=0;
            foreach($configuration as $list)
            {
                $sr++;
                ?>
                <tr>
                    <td><?= $sr;?></td>
                    <td><?= $list->clinic_name;?></td>
                    <td><?= $list->image;?></td>
                    <td><?= $list->owner_name;?></td>
                    <td><?= $list->mobile_no;?></td>
                    <td><?= $list->email_id;?></td>
                    <td><?= substr($list->address,0,20);?></td>
                    <td><a href="<?= site_url('admin/configuration/edit/'.$list->id);?>" class="btn btn-success btn-sm">Edit</a> 
                    <a href="<?= site_url('admin/configuration/delete/'.$list->id);?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
                </tr>
                <?php
            }
        }
        ?>
            </tbody>
        </table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- end page content -->
</div>
<!-- end page container -->
<?php $this->load->view('layout/footer.php');?>