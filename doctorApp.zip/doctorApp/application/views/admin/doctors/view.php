<?php $this->load->view('layout/header.php');?>
<style>
	.swal-wide{
    width:1000px !important;
}
.prbtn{
	width: 100px;
    margin: auto;
    margin-right: 10px;
    top: 0px;
    margin-bottom: 10px;
}

</style>
<div
	class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">
	<?php $this->load->view('layout/top_menu.php');?>   
<?php $this->load->view('layout/left_menu.php');?> 
<!-- end header -->
<!-- start color quick setting -->
<div class="settingSidebar">
	<a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i>
	</a>
	<div class="settingSidebar-body ps-container ps-theme-default">
		<div class=" fade show active">
			<div class="setting-panel-header">Setting Panel
			</div>
		</div>
	</div>
</div>
<!-- end color quick setting -->
<!-- start page container -->
<div class="page-container">
<!-- start page content -->
	<div class="page-content-wrapper">
		<div class="page-content">
			<div class="page-bar">
				<div class="page-title-breadcrumb">
					<div class=" pull-left">
						<div class="page-title"><?php echo $this->lang->line('doctor_profile') ?></div>
					</div>
				</div>
			</div>
	<div class="row">
		<div class="col-md-12">
			<!-- BEGIN PROFILE SIDEBAR -->
			<div class="profile-sidebar">
				<div class="card">
					<div class="card-body no-padding height-9">
						<div class="row">
							<div class="profile-userpic">
								<img src="<?= base_url();?>assets/img/user/<?= $doctor['image'];?>" class="img-responsive" alt="">
							</div>
						</div>
                                         
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"><?= $doctor['name'];?></div>
				<div class="profile-usertitle-job"><?= $doctor['designation'];?></div>
			</div>
			<ul class="list-group list-group-unbordered">
				<li class="list-group-item">
					<b><?php echo $this->lang->line('doctor_code') ?></b> <a class="pull-right"><?= $doctor['code'];?></a>
				</li>
				<li class="list-group-item">
					<b><?php echo $this->lang->line('mobile_no') ?></b> <a class="pull-right"><?= $doctor['mobile_no'];?></a>
				</li>
				<li class="list-group-item">
					<b><?php echo $this->lang->line('city') ?></b> <a class="pull-right"><?= $doctor['city'];?></a>
				</li>
				<li class="list-group-item">
					<b><?php echo $this->lang->line('email_id') ?></b> <a class="pull-right"><?= $doctor['email'];?></a>
				</li>
			</ul>
		</div>
	</div>
</div>
	<!-- BEGIN PROFILE CONTENT -->
	<div class="profile-content">
		<div class="row">
			<div class="card">
				<div class="card-topline-aqua">
					<header></header>
				</div>
				<div class="white-box">
					<!-- Nav tabs -->
					<div class="p-rl-20">
						<ul class="nav customtab nav-tabs" role="tablist">
							<li class="nav-item"><a href="javascript:void(0)" class="nav-link active"
									><?php echo $this->lang->line('about_patients') ?></a></li>
									<li class="nav-item"><a href="javascript:void(0)" data-id="<?= $doctor['id'];?>" class="nav-link active doctordetails" 
									><?php echo $this->lang->line('all_details') ?></a></li>		
						</ul>
					</div>	
<!-- Tab panes -->
	<div class="tab-content">
		<div class="tab-pane active fontawesome-demo" id="tab1">
        <div id="biography">
		<div class="row">
		<div class="table-wrap">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-hover table-checkable order-column"
            id="example4">
					<thead>
						<tr>
							<th class="center"><?php echo $this->lang->line('sr_no') ?></th>
							<th class="center"><?php echo $this->lang->line('patient_name') ?> / <?php echo $this->lang->line('code') ?></th>
							<th class="center"><?php echo $this->lang->line('appointment_datetime') ?></th>
							<th class="center"><?php echo $this->lang->line('status') ?></th>
							<th class="center"><?php echo $this->lang->line('action') ?></th>
						</tr>
					</thead>
		<tbody>
			<?php
			// print_r($doctorApp);
			// exit;
			if(!empty($doctorApp))
			{
				$sr=0;
				foreach($doctorApp as $list)
				{
					$sr++;
					$patientData = $this->common_model->get_name(TBL_PATIENT,$list->patient_id);
				
					// echo $list->date_time;
					?>
					<tr>
						<td class="center">
						<?= $sr;?>
						</td>
						<td class="center">
						<?= $patientData['name'];?>/<?= $patientData['code'];?>
						</td>
						<td class="center">
							<?= $list->date_time;?>
						</td>
						
						<td class="center">
							<?php
							if ($list->is_status== TRUE){
								echo'<span class="label label-sm label-success">Attended</span>';
							}else{
								echo'<span class="label label-sm label-warning ">Not Attended</span>';
							}
							?>
						</td>
						<td class="center">
							<a href="javascript:void(0)" data-id="<?= $list->id;?>" class="tblEditBtn viewData">
								<i class="fa fa-eye"></i>
							</a>
							<a href="<?= site_url('admin/doctors/delete/'.$list->id);?>" class="tblDelBtn" onclick="return confirm('Are you sure to delete?')">
								<i class="fa fa-trash-o"></i>
							</a>
						</td>
						</tr>
				<?php
				}
			}
			$sr++;
			?>
						
		</tbody>
				</table>
			</div>
		</div>
		</div>
	</div>
</div>
	<div class="tab-pane" id="tab2">
		<div class="container-fluid">
			<div class="row">
				<div class="full-width p-rl-20">
					<div class="panel">
					<footer class="panel-footer">
						<button type = "submit"  value="submit"
						href="<?= site_url('admin/patients/view'); ?>" class="btn btn-post pull-right">Save</button>
						<ul class="nav nav-pills p-option">
							<li>
								<a href="#"><i
										class="fa fa-user"></i></a>
							</li>
							<li>
								<a href="#"><i
										class="fa fa-camera"></i></a>
							</li>
							<li>
								<a href="#"><i
										class="fa fa-location-arrow"></i></a>
							</li>
							<li>
								<a href="#"><i
										class="fa fa-meh-o"></i></a>
							</li>
						</ul>
					</footer>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
</div>
<!-- END PROFILE CONTENT -->
</div>
</div>
</div>
<!-- end page content -->
<!-- start chat sidebar -->
<div class="chat-sidebar-container" data-close-on-body-click="false">
	<div class="chat-sidebar">
		<ul class="nav nav-tabs">
			<li class="nav-item">
				<a href="#quick_sidebar_tab_1" class="nav-link active tab-icon" data-bs-toggle="tab"> <i
						class="material-icons">chat</i>Chat
					<span class="badge badge-danger">4</span>
				</a>
			</li>
			<li class="nav-item">
				<a href="#quick_sidebar_tab_3" class="nav-link tab-icon" data-bs-toggle="tab"> <i
						class="material-icons">settings</i>
					Settings
				</a>
			</li>
		</ul>
<div class="tab-content">
	<!-- Start User Chat -->
	<div class="tab-pane active chat-sidebar-chat in active show" role="tabpanel" id="quick_sidebar_tab_1">
		<div class="chat-sidebar-list">
			<div class="chat-sidebar-chat-users slimscroll-style" data-rail-color="#ddd"
				data-wrapper-class="chat-sidebar-list">
				<div class="chat-header">
					<h5 class="list-heading">Online</h5>
				</div>
				<ul class="media-list list-items">
					<li class="media"><img class="media-object"
							src="<?= base_url();?>assets/img/user/user3.jpg" width="35" height="35" alt="...">
						<i class="online dot"></i>
						<div class="media-body">
							<h5 class="media-heading">John Deo</h5>
							<div class="media-heading-sub">Spine Surgeon</div>
						</div>
					</li>
					<li class="media">
						<div class="media-status">
							<span class="badge badge-success">5</span>
						</div> <img class="media-object" src="<?= base_url();?>assets/img/user/user1.jpg"
							width="35" height="35" alt="...">
						<i class="busy dot"></i>
						<div class="media-body">
							<h5 class="media-heading">Rajesh</h5>
							<div class="media-heading-sub">Director</div>
						</div>
					</li>
					<li class="media"><img class="media-object"
							src="<?= base_url();?>assets/img/user/user5.jpg" width="35" height="35" alt="...">
						<i class="away dot"></i>
						<div class="media-body">
							<h5 class="media-heading">Jacob Ryan</h5>
							<div class="media-heading-sub">Ortho Surgeon</div>
						</div>
					</li>
					<li class="media">
						<div class="media-status">
							<span class="badge badge-danger">8</span>
						</div> <img class="media-object" src="<?= base_url();?>assets/img/user/user4.jpg"
							width="35" height="35" alt="...">
						<i class="online dot"></i>
						<div class="media-body">
							<h5 class="media-heading">Kehn Anderson</h5>
							<div class="media-heading-sub">CEO</div>
						</div>
					</li>
					<li class="media"><img class="media-object"
							src="<?= base_url();?>assets/img/user/user2.jpg" width="35" height="35" alt="...">
						<i class="busy dot"></i>
						<div class="media-body">
							<h5 class="media-heading">Sarah Smith</h5>
							<div class="media-heading-sub">Anaesthetics</div>
						</div>
					</li>
					<li class="media"><img class="media-object"
							src="<?= base_url();?>assets/img/user/user7.jpg" width="35" height="35" alt="...">
						<i class="online dot"></i>
						<div class="media-body">
							<h5 class="media-heading">Vlad Cardella</h5>
							<div class="media-heading-sub">Cardiologist</div>
						</div>
					</li>
				</ul>
			<div class="chat-header">
				<h5 class="list-heading">Offline</h5>
			</div>
			<ul class="media-list list-items">
				<li class="media">
					<div class="media-status">
						<span class="badge badge-warning">4</span>
					</div> <img class="media-object" src="<?= base_url();?>assets/img/user/user6.jpg"
						width="35" height="35" alt="...">
					<i class="offline dot"></i>
					<div class="media-body">
						<h5 class="media-heading">Jennifer Maklen</h5>
						<div class="media-heading-sub">Nurse</div>
						<div class="media-heading-small">Last seen 01:20 AM</div>
					</div>
				</li>
				<li class="media"><img class="media-object"
						src="<?= base_url();?>assets/img/user/user8.jpg" width="35" height="35" alt="...">
					<i class="offline dot"></i>
					<div class="media-body">
						<h5 class="media-heading">Lina Smith</h5>
						<div class="media-heading-sub">Ortho Surgeon</div>
						<div class="media-heading-small">Last seen 11:14 PM</div>
					</div>
				</li>
				<li class="media">
					<div class="media-status">
						<span class="badge badge-success">9</span>
					</div> <img class="media-object" src="<?= base_url();?>assets/img/user/user9.jpg"
						width="35" height="35" alt="...">
					<i class="offline dot"></i>
					<div class="media-body">
						<h5 class="media-heading">Jeff Adam</h5>
						<div class="media-heading-sub">Compounder</div>
						<div class="media-heading-small">Last seen 3:31 PM</div>
					</div>
				</li>
				<li class="media"><img class="media-object"
						src="<?= base_url();?>assets/img/user/user10.jpg" width="35" height="35"
						alt="...">
					<i class="offline dot"></i>
					<div class="media-body">
						<h5 class="media-heading">Anjelina Cardella</h5>
						<div class="media-heading-sub">Physiotherapist</div>
						<div class="media-heading-small">Last seen 7:45 PM</div>
					</div>
				</li>
			</ul>
		</div>
	</div>
</div>
</div>
</div>
</div>
<!-- end chat sidebar -->
</div>
<!-- end page container -->
</div>
</div>
<?php $this->load->view('layout/footer.php');?>
</body>
<!-- Mirrored from www.einfosoft.com/templates/admin/smart/source/light/ui_sweet_alert.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 02 Dec 2022 05:43:11 GMT -->
</html>