<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
    <!-- start page container -->
<div class="page-container">
<?php $this->load->view('layout/left_menu.php');?>   
    <!-- start page content -->
    <form action="<?php echo site_url('admin/doctors/edit/'.$doctors['id']); ?>" method="post" enctype="multipart/form-data">
    <input  type="hidden" name="id" value="<?php echo $doctors['id']; ?>"  />
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Dashboard</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                                href="<?php echo site_url('admin/users/index'); ?>"><?php echo $this->lang->line('home') ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                        </li>
                        <li class="active">Dashboard</li>
                    </ol>
                </div>
            </div>
            <!-- start widget -->
                <div class="row">
            <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
                </div> 
            <?php } ?>
            <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
                </div>
            <?php } ?>
            </div> 
            <!-- end widget -->
            <div class="row">
            <div class="col-sm-12">
                <div class="card-box">
                    <div class="card-head">
                        <header><?php echo $this->lang->line('doctors_details') ?></header>
                        <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                            data-mdl-for="panel-button">
                            <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                            </li>
                            <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                            </li>
                            <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                                here</li>
                        </ul>
                    </div>
                    <div class="card-body row">
                        <div class="col-lg-6 p-t-20">
                            <div
                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                <input class="mdl-textfield__input" type="text" name="doctor_name" id="doctor_name" value="<?php echo set_value('name'); ?>" />
                                <label class="mdl-textfield__label" for="error"><?php echo $this->lang->line('doctor_name') ?></label>
                            </div>
                            <label for="error" class="error"><?= form_error('doctor_name'); ?></label>
                        </div>
                        <div class="col-lg-6 p-t-20">
                            <div>
                                <label for="Image"><?php echo $this->lang->line('image') ?></label>
                                <input type="file" class="form-control" class="custom-file-input" name="image" id="image" value="upload" accept="image/jpeg, image/png, image/jpg">
                                <img id="image">
                            </div>
                            <label for="error" class="error"><?= form_error('image'); ?></label>
                            </div>
                        <div class="col-lg-6 p-t-20">
                            <div
                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                <input class="mdl-textfield__input" type="text" name="designation" id="designation" value="<?php echo set_value('designation'); ?>" />
                                <label class="mdl-textfield__label"><?php echo $this->lang->line('designation') ?></label>
                            </div>
                            <label for="error" class="error"><?= form_error('designation'); ?></label>
                        </div>
                        <div class="col-lg-6 p-t-20">
                            <div
                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                <input class="mdl-textfield__input" type="text" name="city" id="city" value="<?php echo set_value('city'); ?>" />
                                <label class="mdl-textfield__label"><?php echo $this->lang->line('city') ?></label>
                            </div>
                            <label for="error" class="error"><?= form_error('city'); ?></label>
                        </div>
                        <div class="col-lg-6 p-t-20">
                            <div
                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                <input class="mdl-textfield__input" type="text" name="age" id="age" value="<?php echo set_value('age'); ?>" />
                                <label class="mdl-textfield__label"><?php echo $this->lang->line('age') ?></label>
                            </div>
                            <label for="error" class="error"><?= form_error('age'); ?></label>
                        </div>
                        <div class="col-lg-6 p-t-20">
                            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                <input class="mdl-textfield__input" type="number" name="m_no" id="m_no"  value="<?php echo set_value('mobile_no'); ?>" />
                                <label class="mdl-textfield__label" for="text7"><?php echo $this->lang->line('mobile_no') ?></label>
                            </div>
                            <label for="error" class="error"><?= form_error('m_no'); ?></label>
                        </div>
                        <div class="col-lg-6 p-t-20">
                            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                <input class="mdl-textfield__input" type="email" name="email" id="email"  value="<?php echo set_value('email'); ?>" />
                                <label class="mdl-textfield__label" for="error"><?php echo $this->lang->line('email_id') ?></label>
                            </div>
                            <label for="error" class="error"><?= form_error('email'); ?></label>
                        </div>
                        
                        <div class="col-lg-12 p-t-20 text-center">
                            <button type="submit" name="submit" value="submit"
                                class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 m-r-20 btn-circle btn-primary"><?php echo $this->lang->line('submit') ?></button>
                            <button type="button" name="cancel" value="cancel"
                                class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 btn-circle btn-danger"><?php echo $this->lang->line('cancel') ?></button>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    <!-- end page content -->
    </form>
</div>
<!-- end page container -->
    
<?php $this->load->view('layout/footer.php');?>