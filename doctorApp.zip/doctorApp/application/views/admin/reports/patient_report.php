<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
<!-- start page container -->
    <div class="page-container">
    <?php $this->load->view('layout/left_menu.php');?>   
    <!-- start page content -->
    <div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title"><?php echo $this->lang->line('all_reports') ?></div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                            href="<?php echo site_url('admin/users/index'); ?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active"><?php echo $this->lang->line('all_reports') ?></li>
                </ol>
            </div>
        </div>
<!-- start widget -->
<!-- end widget -->
    <div class="row">
        <div class="col-sm-12">
        <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
            <div class="alert alert-success alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
            </div>
        <?php } ?>
        <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
            <div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
            </div>
    <?php } ?>
        <div class="card-box">
            <div class="card-head">
                <header><?php echo $this->lang->line('all_reports') ?></header>
                <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                    data-mdl-for="panel-button">
                    <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                    </li>
                    <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                        here</li>
                </ul>
            </div>
    <div class="card-body">
        <form action="<?php echo site_url('admin/reports/patient_report');?>" method="post">
            <div class="row">
                <div class="col-sm-3">
                    <div class="form-label">
                        <label for="sample2" class="form-label" for="error"><?php echo $this->lang->line('select_reports') ?></label>
                        <select name="patient_id" class="form-control">
                            <option value=""><?php echo $this->lang->line('select') ?></option>
                            <?php
                            foreach($patientLists as $list){
                                echo '<option value="'.$list->id.'">'.$list->name.'</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <label for="error" class="error"><?= form_error('patient_id'); ?></label>
                </div>
            <div class="col-sm-3">
                <div class="form-label">
                    <label for="date" class="form-label"><?php echo $this->lang->line('from_date') ?><span class="text-danger">*</span></label>
                    <input type="date" class="form-control" name="from_date" id="from_date">
                </div>
                <label for="error" class="error"><?= form_error('from_date'); ?></label>
            </div>
            <div class="col-sm-3">
                <div class="form-label">
                <label for="date" class="form-label"><?php echo $this->lang->line('to_date') ?><span class="text-danger">*</span></label>
                <input type="date" class="form-control" name="to_date" id="to_date">
            </div>
            <label for="error" class="error"><?= form_error('to_date'); ?></label>
            </div>
            <div class="col-sm-3" style="margin-top: 35px;">
                <button type="submit" name="submit" value="submit" class="btn btn-success btn-sm" value="check"><?php echo $this->lang->line('check') ?></button>
            </div>
        </div>
    </form>
    <div class="table-responsive">
        <table
            class="table table-striped table-bordered table-hover table-checkable order-column"
            id="example4">
            <thead>
                <tr>
                    <th><?php echo $this->lang->line('sr_no') ?></th>
                    <th class="center"><?php echo $this->lang->line('patient_name') ?></th>
                    <th class="center"><?php echo $this->lang->line('doctor_name') ?></th>
                    <th class="center"><?php echo $this->lang->line('appointment_datetime') ?></th>
                    <th class="center"><?php echo $this->lang->line('action') ?></th>
                </tr>
            </thead>
        <tbody>
            <?php 
        if(!empty($result))
        {
            $sr=0;
            foreach($result as $list)
            {
                $sr++;
                $patientsData = $this->common_model->get_name(TBL_PATIENT,$list->patient_id);
                $doctorsData = $this->common_model->get_name(TBL_DOCTOR,$list->doctor_id);
            ?>
            <tr>
                <td>
                    <?= $sr;?>
                </td>
                <td>
                    <?= $patientsData['name'];?>/<?= $patientsData['code'];?>
                </td>
                <td>
                    <?= $doctorsData['name'];?>/<?= $doctorsData['code'];?>
                </td>
                <td>
                    <?= $list->date_time;?>
                </td>
                <td>
                <?php
                    if ($list->is_status== TRUE){
                        echo'<span class="label label-sm label-success">Attended</span>';
                    }else{
                        echo'<span class="label label-sm label-warning ">Not Attended</span>';
                    }
                    ?>
                </td>
            </tr>
            <?php
                    }
                }
            ?>
            </tbody>
        </table>
    </div>
</div>
</div>     
</div>
</div>
</div>
</div>
<!-- end page content -->
</div>
<!-- end page container -->
<?php $this->load->view('layout/footer.php');?>