<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
<!-- start page container -->
<div class="page-container">
<?php $this->load->view('layout/left_menu.php');?>   
<!-- start page content -->
<form action="<?php echo site_url('admin/patients/appointment_form');?>" method="post">
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title">Patient Invoice</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                            href="<?php echo site_url('admin/users/index'); ?>"><?php echo $this->lang->line('home') ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active">Patient Invoice</li>
                </ol>
            </div>
        </div>
<!-- start widget -->
<!-- end widget -->
<div class="row">
<div class="col-sm-12">
<?php if(!empty($this->session->flashdata('success_msg'))){ ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
    </div>
<?php } ?>
<?php if(!empty($this->session->flashdata('error_msg'))){ ?>
    <div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
    </div>
<?php } ?>
<div class="row">
<?php 
            if(!empty($result))
            {
				$apData = $this->common_model->get_name(TBL_APPOINTMENT,$result['appointment_id']);
                $patientData = $this->common_model->get_name(TBL_PATIENT,$apData['patient_id']);
                $doctorData = $this->common_model->get_name(TBL_DOCTOR,$apData['doctor_id']);
				$loggedIn = $this->session->userdata("user_login");
				$ownerData = $this->common_model->get_name(TBL_CONFIGURATION,$loggedIn['clinic_id']);

					// print_r($ownerData);
					// exit;
        ?>
						<div class="col-md-12">
							<div class="white-box">
								<h3><b>INVOICE</b> <span class="pull-right"><?= $result['code'];?></span></h3>
								<hr>
								<div class="row">
									<div class="col-md-12">
										<div class="pull-left">
											<address>
											<a href="">
											<span class="logo-icon material-icons fa-rotate-45">school</span>
                                            <span class="logo-default"><h3>DoctorApp</h3></span></a>
												<p class="text-muted m-l-5">
												<?= $ownerData['address'];?>
												</p>
											</address>
										</div>
										<div class="pull-right text-right" >
											<address>
												<p class="addr-font-h3">To,</p>
												<p class="font-bold addr-font-h4" ><?= $patientData['name'];?></p>
												<p class="text-muted m-l-30">
												<?= $patientData['city'];?>
												</p>
												<p class="m-t-30">
													<b>Invoice Date :</b> <?= $result['collection_date'];?>
												</p>
												
											</address>
										</div>
										
									</div>
									<div class="col-md-12">
										<div class="table-responsive m-t-40">
											<table class="table table-hover">
												<thead>
													<tr>
													
														<th class="text-right">Fees Type</th>
														<th class="text-right">Appointment Date</th>
														<th class="text-right">Invoice number</th>
														<th class="text-right">Amount</th>
														<th class="text-right">Payment Status</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td class="text-right"><?= $result['fees_type'];?></td>
														<td class="text-right"><?= $apData['date_time'];?></td>
														<td class="text-right"><?= $result['code'];?></td>
														<td class="text-right"><?= $result['amount'];?></td>
														<td class="text-right"><?= $result['payment_status'];?></td>
													</tr>
													<?php
            }
        ?>
												</tbody>
											</table>
										</div>
									</div>
									<div class="col-md-12">
										<div class="pull-right m-t-30 text-right">
										<hr>
										<h3><b>Total :</b><?= $result['amount'];?></h3>
										</div>
										<div class="clearfix"></div>
										<hr>
										<div class="text-right">
											<!-- <button class="btn btn-danger" type="submit"> Proceed to payment </button> -->
											<button onclick="javascript:window.print();"
												class="btn btn-default btn-outline" type="button"> <span><i
														class="fa fa-print"></i> Print</span> </button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
</div>
</div>
</div>
</div>
        <!-- end page content -->
</form>
</div>
<!-- end page container -->

<?php $this->load->view('layout/footer.php');?>