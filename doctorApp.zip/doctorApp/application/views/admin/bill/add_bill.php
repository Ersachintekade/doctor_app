<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
<!-- start page container -->
<div class="page-container">
<?php $this->load->view('layout/left_menu.php');?>   
<!-- start page content -->
<form action="<?php echo site_url('admin/bill/add_bill');?>" method="post">
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title"><?php echo $this->lang->line('add_fees') ?></div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                            href="<?php echo site_url('admin/users/index'); ?>"><?php echo $this->lang->line('home') ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active"><?php echo $this->lang->line('add_fees') ?></li>
                </ol>
            </div>
        </div>
<!-- start widget -->
<!-- end widget -->
<div class="row">
<div class="col-sm-12">
<?php if(!empty($this->session->flashdata('success_msg'))){ ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
    </div>
<?php } ?>
<?php if(!empty($this->session->flashdata('error_msg'))){ ?>
    <div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
    </div>
<?php } ?>
    <div class="card-box">
    <div class="card-head">
        <header class="info-box-title"><?php echo $this->lang->line('add_fees') ?></header>
        <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
            data-mdl-for="panel-button">
            <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action</li>
            <li class="mdl-menu__item"><i class="material-icons">print</i>Another action</li>
            <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else here</li>
        </ul>
    </div>
    
    <div class="card-body row">
        <form action="<?php echo site_url('admin/bill/add_bill');?>" method="post">
        <div class="row">    
            <div class="col-sm-3">
                <label for="date" class="form-label"><?php echo $this->lang->line('appointment_code') ?><span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="appointment_code" id="appointment_code" placeholder="Enter Appointment Code" value="<?php echo set_value('appointment_code'); ?>">
                <label for="error" class="error"><?= form_error('appointment_code'); ?></label>
            </div>
            <div class="col-sm-3" style="margin-top: 35px;">
            <button type="submit" name="submit" value="submit" class="btn btn-success btn-sm"><?php echo $this->lang->line('submit') ?></button>
            </div>
        </div>
        </form>
    </div>
    <div class="card-body" id="bar-parent">
	<?php 
            if(!empty($result))
            {
                    $patientData = $this->common_model->get_name(TBL_PATIENT,$result['patient_id']);
                    $doctorData = $this->common_model->get_name(TBL_DOCTOR,$result['doctor_id']);
        ?>
									<form class="form-horizontal" action="<?php echo site_url('admin/bill/generate_bill');?>" method="post">
									<input type="hidden" class="form-control" name="appointment_id" id="appointment_id" value="<?php echo $result['id']; ?>">
										<div class="form-body">
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('patient_name') ?><span class="required"> * </span></label>
												<div class="col-md-5">
													<input type="text" name="patient_id" id="patient_id" value="<?= $patientData['name'] ;?>" class="form-control input-height" />
												</div>
												<label for="error" class="error"><?= form_error('patient_id'); ?></label>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('doctor_name') ?><span class="required"> * </span></label>
												<div class="col-md-5">
												<input type="text" name="doctor_id" id="doctor_id" value="<?= $doctorData['name'] ;?>" class="form-control input-height" />
												</div>
												<label for="error" class="error"><?= form_error('doctor_id'); ?></label>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('fees_type') ?><span class="required"> * </span></label>
												<div class="col-md-5">
													<select class="form-select input-height" name="fees_type" id="fees_type" value="<?= $patientData['fees_type'] ;?>">
														<option value=""><?php echo $this->lang->line('select') ?></option>
														<option value="OPD"><?php echo $this->lang->line('opd') ?></option>
														<option value="FIRST CHECKUP"><?php echo $this->lang->line('first_checkup') ?></option>
														<option value="RECHECKUP"><?php echo $this->lang->line('recheckup') ?></option>
														<option value="ADMIT"><?php echo $this->lang->line('admit') ?></option>
														
													</select>
												</div>
												<label for="error" class="error"><?= form_error('fees_type'); ?></label>
											</div>
											
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('amount') ?><span class="required"> * </span></label>
												<div class="col-md-5">
													<input name="amount" id="amount" type="text" placeholder="<?php echo $this->lang->line('enter_amount') ?>" class="form-control input-height" value="<?= $patientData['fees_type'] ;?>" readonly/> 
												</div>
												<label for="error" class="error"><?= form_error('amount'); ?></label>
											</div>
											
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('collection_date') ?><span class="required"> * </span></label>
												<div class="col-md-5">
													<div class="input-append date">
														<div id="dateIcon" class="input-group datePicker">
															<input class="formDatePicker form-control" type="text" name="collection_date" id="collection_date" placeholder="<?php echo $this->lang->line('select_date') ?>" data-input="">
															<span class="dateBtn">
																<a class="input-button" title="toggle" data-toggle>
																	<i class="icon-calendar"></i>
																</a>
																<a class="input-button" title="clear" data-clear>
																	<i class="icon-close"></i>
																</a>
															</span>
														</div>
													</div>
												</div>
												<label for="error" class="error"><?= form_error('collection_date'); ?></label>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('payment_method') ?><span class="required"> * </span></label>
												<div class="col-md-5">
													<select class="form-select input-height" name="payment_method" id="payment_method" value="<?= $patientData['payment_method'] ;?>">
														<option value=""><?php echo $this->lang->line('select') ?></option>
														<option value="Cash"><?php echo $this->lang->line('cash') ?></option>
														<option value="Cheque"><?php echo $this->lang->line('cheque') ?></option>
														<option value="Credit Card"><?php echo $this->lang->line('credit_card') ?></option>
														<option value="Debit Card"><?php echo $this->lang->line('debit_card') ?></option>
														<option value="Netbanking"><?php echo $this->lang->line('net_banking') ?></option>
														<option value="Other"><?php echo $this->lang->line('others') ?></option>
													</select>
												</div>
												<label for="error" class="error"><?= form_error('payment_method'); ?></label>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('reference_name') ?><span class="required"> * </span></label>
												<div class="col-md-5">
													<input name="reference_name" id="reference_name" type="text" placeholder="<?php echo $this->lang->line('enter_refname') ?>" class="form-control input-height" value="<?= $patientData['reference_name'] ;?>" />
												</div>
												<label for="error" class="error"><?= form_error('reference_name'); ?></label>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('payment_status') ?><span class="required"> * </span></label>
												<div class="col-md-5">
													<select class="form-select input-height" name="payment_status" id="payment_status" value="<?= $patientData['payment_status'] ;?>">
														<option value=""><?php echo $this->lang->line('select') ?></option>
														<option value="Paid"><?php echo $this->lang->line('paid') ?></option>
														<option value="Unpaid"><?php echo $this->lang->line('unpaid') ?></option>
														<option value="Pending"><?php echo $this->lang->line('pending') ?></option>
													</select>
												</div>
												<label for="error" class="error"><?= form_error('payment_status'); ?></label>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3" for="error"><?php echo $this->lang->line('payment_details') ?></label>
												<div class="col-md-5">
													<textarea name="payment_details" id="payment_details" placeholder="<?php echo $this->lang->line('payment_details') ?>" class="form-control-textarea" rows="5"></textarea>
												</div>
											</div>
											<label for="error" class="error"><?= form_error('payment_details'); ?></label>
										</div>
										<div class="form-actions">
											<div class="row">
												<div class="offset-md-3 col-md-9">
													<button type="submit" name="submit" value="submit" class="btn btn-info m-r-20">Submit</button>
													<a href="<?php echo site_url('admin/bill/add_bill');?>"><button type="button" class="btn btn-default">Cancel</button></a>
												</div>
											</div>
										</div>
									</form>
									<?php
                        }
                    
                ?>
								</div>
</div>
</div>
</div>
</div>
</div>
        <!-- end page content -->
        </form>
</div>
<!-- end page container -->

<?php $this->load->view('layout/footer.php');?>