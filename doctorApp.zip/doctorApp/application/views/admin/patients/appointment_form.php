<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
<!-- start page container -->
<div class="page-container">
<?php $this->load->view('layout/left_menu.php');?>   
<!-- start page content -->
<form action="<?php echo site_url('admin/patients/appointment_form');?>" method="post">
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title"><?php echo $this->lang->line('appointment_form') ?></div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                            href="<?php echo site_url('admin/users/index'); ?>"><?php echo $this->lang->line('home') ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active"><?php echo $this->lang->line('appointment_form') ?></li>
                </ol>
            </div>
        </div>
<!-- start widget -->
<!-- end widget -->
<div class="row">
<div class="col-sm-12">
<?php if(!empty($this->session->flashdata('success_msg'))){ ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
    </div>
<?php } ?>
<?php if(!empty($this->session->flashdata('error_msg'))){ ?>
    <div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
    </div>
<?php } ?>
    <div class="card-box">
    <div class="card-head">
        <header class="info-box-title"><?php echo $this->lang->line('appointment_details') ?></header>
        <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
            data-mdl-for="panel-button">
            <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action</li>
            <li class="mdl-menu__item"><i class="material-icons">print</i>Another action</li>
            <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else here</li>
        </ul>
    </div>
    <div class="card-body row">
    <div class="col-lg-6 p-t-20">
        <div
            class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
            <label class="mdl-textfield__label" for="error" ><?= form_error('patient_id'); ?><?php echo $this->lang->line('patient_name') ?></label>
            <select name="patient_id" class="mdl-textfield__input">
                <option value=""></option>
                <?php
                foreach($patientLists as $list){
                    echo '<option value="'.$list->id.'">'.$list->name.'</option>';
                }
                ?>
            </select>
        </div>
            <label for="error" class="error"><?= form_error('patient_id'); ?></label>
    </div>
    <div class="col-lg-6 p-t-20">
        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
            <label class="mdl-textfield__label" for="error" class="error"><?= form_error('doctor_id'); ?><?php echo $this->lang->line('doctor_name') ?></label>
            <select name="doctor_id" class="mdl-textfield__input">
                <option value=""> </option>
                <?php
                foreach($doctorLists as $list){
                    echo '<option value="'.$list->id.'">'.$list->name.'</option>';
                }
                ?>
            </select>
        </div>
        <label for="error" class="error"><?= form_error('doctor_id'); ?></label>
    </div>
    <div class="col-lg-6 p-t-20">
        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width is-upgraded is-dirty" data-upgraded=",MaterialTextfield">
        <input class="mdl-textfield__input flatpickr-input active" type="text" name="date_time" id="datetime" readonly="readonly">
        <label class="mdl-textfield__label"><?php echo $this->lang->line('select_datetime') ?></label>
    </div>
        <label for="error" class="error"><?= form_error('date_time'); ?></label>
    </div>
    <div class="col-lg-6 p-t-20">
        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
            <textarea class="mdl-textfield__input" rows="1" name="patient_description" id="text7"></textarea>
            <label class="mdl-textfield__label" for="text7"><?php echo $this->lang->line('patient_description') ?></label>
        </div>
            <label for="error" class="error"><?= form_error('patient_description'); ?></label>
    </div>
    <div class="col-lg-12 p-t-20 text-center">
        <button type="submit" name="submit" value="submit"
            class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 m-r-20 btn-circle btn-primary"><?php echo $this->lang->line('submit') ?></button>
            <a href="<?php echo site_url('admin/users/index');?>"><button type="button" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 btn-circle btn-danger"><?php echo $this->lang->line('cancel') ?></button></a>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
        <!-- end page content -->
        </form>
</div>
<!-- end page container -->

<?php $this->load->view('layout/footer.php');?>