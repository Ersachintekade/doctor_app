<div id="container">
<div style ='margin:0 auto; text-align:center'>
      <a href="<?php echo base_url("admin/users/switchLang/english"); ?>">English</a> |
      <a href="<?php echo base_url("admin/users/switchLang/hindi"); ?>">Hindi</a> |
      <a href="<?php echo base_url("admin/users/switchLang/marathi"); ?>">Marathi</a> |
    </div>
  <h1><?php echo $this->lang->line('welcome') ?></h1>
  <div id="body">
   <?php print_r($lang); ?>
    <p><?php echo $this->lang->line('message') ?></p>
    </div>
</div>