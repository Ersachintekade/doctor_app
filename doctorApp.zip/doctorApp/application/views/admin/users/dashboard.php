<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
<!-- start page container -->   
<div class="page-container">
    <?php $this->load->view('layout/left_menu.php');?>   
   
    <!-- start page content -->
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="page-bar">
                    <div class="page-title-breadcrumb">
                        <div class="pull-left">
                            <h3 class="page-title"><?php echo $this->lang->line('dashboard') ?></h3>
                        </div>
                        <ol class="breadcrumb page-breadcrumb pull-right">
                            <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                                    href="<?php echo site_url('admin/users/index'); ?>"><?php echo $this->lang->line('home') ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                            </li>
                            <li class="active"><?php echo $this->lang->line('dashboard') ?></li>
                        </ol>
                    </div>
                </div>
                <!-- start widget -->
                <div class="row">
                <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
                    </div>
                <?php } ?>
                <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
                    </div>
                </div>
                <?php } ?>
                    <div class="col-xl-5">
                        <div class="w-100">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h4 class="info-box-title"><?php echo $this->lang->line('total_doctors') ?></h4>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="l-bg-green info-icon">
                                                        <i class="fa fa-users pull-left col-orange font-30"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <h1 class="mt-1 mb-3 info-box-title">               
                                                <?php
                                                $dcount = $this->common_model->all_count(TBL_DOCTOR,array());
                                                echo $dcount?$dcount:0;
                                                ?>
                                            </h1>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h4 class="info-box-title"><?php echo $this->lang->line('total_patients') ?></h4>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="l-bg-green info-icon">
                                                        <i class="fa fa-users pull-left col-orange font-30"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <h1 class="mt-1 mb-3 info-box-title">
                                            <?php 
                                            $pcount = $this->common_model->all_count(TBL_PATIENT,array());
                                            echo $pcount?$pcount:0;
                                            ?>  
                                            </h1>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h4 class="info-box-title"><?php echo $this->lang->line('today_patients') ?></h4>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="col-teal info-icon">
                                                        <i class="fa fa-user pull-left card-icon font-30"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <h1 class="mt-1 mb-3 info-box-title">
                                            <?php
                                            $nextDay = date("Y-m-d", time() + 86400);
                                            $dwcount = $this->common_model->all_count(TBL_APPOINTMENT,array('date_time >='=>date('Y-m-d'),'date_time <'=>$nextDay));
                                            echo $dwcount?$dwcount:0;
                                            ?>
                                            </h1>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h4 class="info-box-title"><?php echo $this->lang->line('attand_patients') ?></h4>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="col-teal info-icon">
                                                        <i class="fa fa-user pull-left card-icon font-30"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <h1 class="mt-1 mb-3 info-box-title">
                                            <?php
                                            $apcount = $this->common_model->all_count(TBL_APPOINTMENT,array("is_status"=>true));
                                            echo $apcount?$apcount:0;
                                            ?>
                                            </h1>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h4 class="info-box-title"><?php echo $this->lang->line('notattand_patients') ?></h4>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="col-teal info-icon">
                                                        <i class="fa fa-user pull-left card-icon font-30"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <h1 class="mt-1 mb-3 info-box-title">
                                            <?php
                                            $notcount = $this->common_model->all_count(TBL_APPOINTMENT,array("is_status"=>false));
                                            echo $notcount?$notcount:0;
                                            ?>
                                            </h1>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h4 class="info-box-title"><?php echo $this->lang->line('alltime_enquiry') ?></h4>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="l-bg-green info-icon">
                                                        <i class="fa fa-users pull-left col-orange font-30"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <h1 class="mt-1 mb-3 info-box-title">
                                            <?php
                                            $totalcount = $this->common_model->all_count(TBL_APPOINTMENT,array());
                                            echo $totalcount?$totalcount:0;
                                            ?>
                                            </h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--chart start-->
                    <div class="col-xl-7">
                        <div class="card card-box">
                            <div class="card-head">
                            <header class="info-box-title"><?php echo $this->lang->line('piebar_chart') ?></header>
                            </div>
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
                                   <div class="recent-report__chart">
                                        <div id="appAllData"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
                                    <div class="card-body">
                                        <div class="recent-report__chart">
                                            <div id="appBarData"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>   
                        </div>
                    </div>
                <!--chart closed-->
                <!-- end widget -->
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                        <div class="card card-box">
                            <div class="card-head">
                                <header class="info-box-title"><?php echo $this->lang->line('allenquiry_index') ?></header>
                                <div class="tools">
                                    <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                </div>
                            </div>
                            <div class="card-body no-padding height-9">
                                <div class="row table-padding">
                                    <div class="col-md-6 col-sm-6 col-6">
                                        <div class="btn-group">
                                            <a href="<?php echo site_url('admin/patients/appointment_form');?>" id="addRow" class="btn btn-info">
                                            <?php echo $this->lang->line('add_new') ?><i class="fa fa-plus"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-6">
                                        <div class="btn-group pull-right">
                                            <a class="btn deepPink-bgcolor  btn-outline dropdown-toggle"
                                                data-bs-toggle="dropdown"><?php echo $this->lang->line('tools') ?>
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li>
                                                    <a href="javascript:;">
                                                        <i class="fa fa-print"></i><?php echo $this->lang->line('print') ?></a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;">
                                                        <i class="fa fa-file-pdf-o"></i><?php echo $this->lang->line('saveas_pdf') ?></a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;">
                                                        <i class="fa fa-file-excel-o"></i><?php echo $this->lang->line('export_excel') ?></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table
                                        class="table table-striped table-bordered table-hover table-checkable order-column"
                                        id="example1">
                                        <thead>
                                            <tr>
                                                <th class="center"><?php echo $this->lang->line('sr_no') ?></th>
                                                <th class="center"><?php echo $this->lang->line('patient_name') ?></th>
                                                <th class="center">Appointment Code</th>
                                                <th class="center"><?php echo $this->lang->line('doctor_name') ?></th>
                                                <th class="center"><?php echo $this->lang->line('appointment_datetime') ?></th>
                                                <th class="center"><?php echo $this->lang->line('status') ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(!empty($patientApp))
                                        {
                                            $sr=0;
                                            
                                            foreach($patientApp as $list)
                                            {
                                                $sr++;
                                                
                                                $patientData = $this->common_model->get_name(TBL_PATIENT,$list->patient_id);
                                                $doctorData = $this->common_model->get_name(TBL_DOCTOR,$list->doctor_id);
                                                // $appointData = $this->common_model->get_name(TBL_APPOINTMENT,$list->code);
                                                ?>
                                                <tr>
                                                    <td class="center"><?= $sr;?></td>
                                                    <td class="center"><?= $patientData['name'];?></td>
                                                    <td class="center"><?= $list->code;?></td>
                                                    <td class="center"><?= $doctorData['name'];?></td>
                                                    <td class="center"><?= $list->date_time;?></td>
                                                    <td class="center"><span class="label label-sm label-warning ">Not Attended</span></td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        $sr++;
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                        <div class="card card-box">
                            <div class="card-head">
                                <header class="info-box-title"><?php echo $this->lang->line('doctors_list') ?></header>
                            </div>
                            <div class="card-body">
                                <?php
                                if(!empty($doctors))
                                {
                                    $sr=0;
                                    foreach($doctors as $data)
                                    {
                                        $sr++;
                                        ?>  
                                <div class="row">   
                                    <ul class="docListWindow medium-slimscroll-style">
                                        <li>
                                            <div class="prog-avatar">
                                                <img src="<?= base_url();?>assets/img/user/<?= $data->image;?>" class="img-responsive" alt="" width="80"
                                                    height="60">
                                            </div>
                                            <div class="details">
                                                <div class="title">
                                                    <a href=""><?= $data->name;?> - <?= $data->designation;?></a>
                                                </div>
                                                <div>
                                                    <span class="clsAvailable">Available</span>
                                                </div>
                                        </li> 
                                    </ul>
                                    <?php
                                            }
                                        }
                                        $sr++;
                                        ?>
                                        </div>
                                    <div class="full-width text-center p-t-10">
                                        <a href="<?php echo site_url('admin/doctors/index');?>" class="btn purple btn-outline btn-circle margin-0"><?php echo $this->lang->line('view_all') ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!-- end page content -->
<!-- start chat sidebar -->
<!-- end chat sidebar -->
</div>
<!-- end page container -->
<?php $this->load->view('layout/footer.php');?>
<?php
$usercount = $this->common_model->all_count(TBL_USER,array());
$monthYear = array(
    "01"=>"Jan",
    "02"=>"Feb",
    "03"=>"Mar",
    "04"=>"Apr",
    "05"=>"May",
    "06"=>"Jun",
    "07"=>"Jul",
    "08"=>"Aug",
    "09"=>"Sep",
    "10"=>"Oct",
    "11"=>"Nov",
    "12"=>"Dec",
);
$monCat='';
$montotal ='';
$monatt ='';
$monnot ='';
foreach($monthYear as $k=>$v)
{
$monCat .= '"'.$v.'",';
$totalCount = $this->common_model->all_count(TBL_APPOINTMENT,array("DATE_FORMAT(date_time, '%Y-%m') ="=>date('Y-'.$k)));
$attCount = $this->common_model->all_count(TBL_APPOINTMENT,array("DATE_FORMAT(date_time, '%Y-%m') ="=>date('Y-'.$k),'is_status'=>true));
$attnotCount = $this->common_model->all_count(TBL_APPOINTMENT,array("DATE_FORMAT(date_time, '%Y-%m') ="=>date('Y-'.$k),'is_status'=>false));
$montotal .= $totalCount.',';
$monatt .= $attCount.',';
$monnot .= $attnotCount.',';
}
?>  
<script>
$(document).ready(function() {
    var options = {
          chart: {
            width: 360,
            type: "pie",
          },
          labels: ["<?php echo $this->lang->line('users')?>", "<?php echo $this->lang->line('doctors') ?>", "<?php echo $this->lang->line('patients') ?>"],
          series: [<?php echo $usercount?>, <?php echo $dcount?>, <?php echo $pcount;?>],
          responsive: [
            {
              breakpoint: 480,
              options: {
                chart: {
                  width: 200,
                },
                legend: {
                  position: "bottom",
                },
              },
            },
          ],
        };
    var chart = new ApexCharts(document.querySelector("#appAllData"), options);
    chart.render();
});

$(document).ready(function() {
    var options = {
    chart: {
      height: 350,
      type: "bar",
    },
    plotOptions: {
      bar: {
        horizontal: false,
        endingShape: "rounded",
        columnWidth: "55%",
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ["transparent"],
    },
    series: [
      {
        name: "<?php echo $this->lang->line('total') ?>",
        data: [<?php echo $montotal;?>],
      },
      {
        name: "<?php echo $this->lang->line('attand') ?>",
        data: [<?php echo $monatt;?>],
      },
      {
        name: "<?php echo $this->lang->line('not_attand') ?>",
        data: [<?php echo $monnot;?>],
      },
    ],
    xaxis: {
      categories: [<?php echo $monCat;?>],
      labels: {
        style: {
          colors: "#9aa0ac",
        },
      },
    },
    yaxis: {
      title: {
        text: "Patient's Count",
      },
      labels: {
        style: {
          colors: "#9aa0ac",
        },
      },
    },
    fill: {
      opacity: 1,
    },
  };
  var chart = new ApexCharts(document.querySelector("#appBarData"), options);
  chart.render();
});
</script>
