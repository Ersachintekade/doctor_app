<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
<!-- start page container -->
<div class="page-container">
<?php $this->load->view('layout/left_menu.php');?>   
<!-- start page content -->
        <form action="<?php echo site_url('admin/users/help');?>" method="post" enctype="multipart/form-data" >
        <input  type="hidden" name="id" value="<?php echo set_value('id'); ?>"  />
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="page-bar">
                    <div class="page-title-breadcrumb">
                        <div class=" pull-left">
                            <div class="page-title">Dashboard</div>
                        </div>
                        <ol class="breadcrumb page-breadcrumb pull-right">
                            <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                                    href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                            </li>
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                <!-- start widget -->
                <div class="row">
                <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
                    </div> 
                <?php } ?>
                <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
                    </div>
                <?php } ?>
                </div> 
                <!-- end widget -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="card-box">
                        <div class="card-head">
                            <header><h3><?php echo $this->lang->line('helpme') ?></h3></header>
                        </div>
                        <div class="card-body">
                        <div class="row">
						<div class="col-sm-12">
							<div class="borderBox light bordered">
								<div class="row">
									<div class="col-sm-12">
										<div class="contact-map">
											<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14889.206292438137!2d79.100778!3d21.1005398!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xfb6b11c1f9b6cde8!2sTenaciousys%20IT-Solutions%20(OPC)Pvt.Ltd!5e0!3m2!1sen!2sin!4v1655983804599!5m2!1sen!2sin" width="900" height="480"></iframe>
										</div>
									</div>
								</div>
								<div class="row m-t-50 m-b-30">
									<div class="col-md-10 col-md-offset-1">
										<div class="row m-b-20">
											<div class="col-sm-12">
												<h3 class="title"><?php echo $this->lang->line('helpmessage') ?></h3>
                                                <img src="<?= base_url();?>assets/img/tenaciousys-logo.png"  width="150" height="60">
												<p class="text sub-title">
												<?php echo $this->lang->line('comp_description') ?></p>
											</div>
										</div>
										<div class="row">
											<!-- Contact form -->
											<div class="col-sm-6">
												<form name="ajax-form" action="<?php echo site_url('admin/users/help');?>" method="post" class="contact-form">
                                                    
                                                    <div class="form-group">
                                                        <label for="error"><?php echo $this->lang->line('name') ?></label>
                                                            <input class="form-control" id="name" name="name"
                                                                placeholder="<?php echo $this->lang->line('your_name') ?>" type="text" value="<?php echo set_value('name');?>">
                                                            <label for="error" class="error"><?= form_error('name'); ?></label>
                                                    </div>
                                                    <div class="form-group">
                                                    <label><?php echo $this->lang->line('mobile_no') ?></label>
														<input class="form-control" id="mobile_no" name="mobile_no"
															placeholder="<?php echo $this->lang->line('your_mobileno') ?>" type="text" value="<?php echo set_value('mobileno');?>">
                                                        <label for="error" class="error"><?= form_error('mobile_no'); ?></label>
													</div>
													<!-- /Form-name -->
													<div class="form-group">
                                                    <label><?php echo $this->lang->line('email_id') ?></label>
														<input class="form-control" id="email" name="email"
															type="email" placeholder="<?php echo $this->lang->line('your_emailid') ?>" value="<?php echo set_value('email'); ?>" >
                                                        <label for="error" class="error"><?= form_error('email'); ?></label>
													</div>
													<!-- /Form-email -->
													<div class="form-group">
                                                    <label><?php echo $this->lang->line('send_message') ?></label>
														<textarea class="form-control" id="message" name="message"
															rows="5" placeholder="<?php echo $this->lang->line('comment') ?>" value="<?php echo set_value('message'); ?>"></textarea>
                                                        <label for="error" class="error"><?= form_error('message'); ?></label>
													</div>
													<!-- /Form Msg -->
													<div class="row">
														<div class="col-12">
															<div class="">
																<button type="submit" name="submit" value="submit"
																	class="btn btn-primary waves-effect waves-light"
																	id="submit"><?php echo $this->lang->line('submit') ?></button>
															</div>
														</div> 
													</div> 
												</form>
											</div>
											<div class="col-sm-4 col-sm-offset-1">
												<div class="contact-box">
													<div class="contact-detail">
														<i class="fa fa-map-marker"></i>
														<span>
                                                            141, Adhyapak Nagar, 
																Manewada, Nagpur, 
																Maharashtra 440034
														</span>
													</div>
													<div class="contact-detail">
														<i class="fa fa-mobile"></i>
														<span>
															<a href="mailto: ">(+91) 983-468-7079</a>
														</span>
													</div>
													<div class="contact-detail">
														<i class="fa fa-envelope"></i>
														<span>
															<a href="https://tenaciousys.com/contact.php">connect@tenaciousys.com</a>
														</span>
													</div>
												</div>
											</div> <!-- end col -->
										</div>
									</div>
								</div>
								<!-- end row -->
							</div>
						</div>
					</div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- end page content -->
    </div>
    <!-- end page container -->
<?php $this->load->view('layout/footer.php');?>