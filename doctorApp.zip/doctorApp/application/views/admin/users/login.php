<!doctype html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
<link href="<?= base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url();?>assets/css/pages/login.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Login #7</title>
<body>
<div class="content">
<div class="container">
<div class="row">
<div class="col-md-6">
<img src="<?= base_url();?>/assets/img/logo_doctor.png" alt="Image" class="img-fluid pull-right">
</div>
<div class="col-md-6 contents">
<div class="row justify-content-center">
<div class="col-md-8">
<div class="mb-4">
<h3>Sign In</h3>
<p class="mb-4">Lorem ipsum dolor sit amet elit. Sapiente sit aut eos consectetur adipisicing.</p>
</div>
<form class="<?= site_url('admin/users/login');?>" id="login-form" method="post">
<label for="error">User Name</label>
<div>
<div class="form-group first">
<input type="text" class="form-control" id="username" name="username" value="<?= set_value('username'); ?>" />
</div>
<label for="error" class="error"><?= form_error('username'); ?></label>
</div>
<label for="error">Password</label>
<div>
<div class="form-group first">
<input type="password" class="form-control" id="password" name="password" value="<?= set_value('password'); ?>">
</div>
<label for="error" class="error"><?= form_error('password'); ?></label>
</div>
<div  class="pull-right">
<label class="control control--checkbox mb-0"><span class="caption"><a href="<?php echo site_url('admin/users/setting');?>" class="forgot-pass">Forgot Password</a></span>
</label>
</div>
<input type="submit" value="submit" name="submit" id="signin" value="Log In" class="btn btn-block btn-primary">
<span class="d-block text-left my-4 text-muted">&mdash; or login with &mdash;</span>
<div class="social-login">
<a href="https://api.whatsapp.com/send?text=<?php echo base_url() . $_SERVER['REQUEST_URI']; ?>" class="facebook">
<span class="fa fa-facebook mr-3"></span>
</a>
<a href="#" class="twitter">
<span class="fa fa-twitter mr-3"></span>
</a>
<a href="#" class="google">
<span class="fa fa-google mr-3"></span>
</a>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>