<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
    <!-- start page container -->
    <div class="page-container">
    <?php $this->load->view('layout/left_menu.php');?>   
    <!-- start page content -->
        <form action="<?php echo site_url('admin/users/notification');?>" method="post" enctype="multipart/form-data" >
        <input  type="hidden" name="id" value="<?php echo set_value('id'); ?>"  />
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="page-bar">
                    <div class="page-title-breadcrumb">
                        <div class=" pull-left">
                            <div class="page-title"><?php echo $this->lang->line('notattand_patients') ?></div>
                        </div>
                        <ol class="breadcrumb page-breadcrumb pull-right">
                            <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                                    href="index-2.html"><?php echo $this->lang->line('home') ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                            </li>
                            <li class="active"><?php echo $this->lang->line('notattand_patients') ?></li>
                        </ol>
                    </div>
                </div>
                <!-- start widget -->
                <div class="row">
                <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
                    </div> 
                <?php } ?>
                <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
                    </div>
                <?php } ?>
                </div> 
                <!-- end widget -->
                <div class="row">
                <div class="col-sm-12">
                    <div class="card-box">
                        <div class="card-head">
                            <header><?php echo $this->lang->line('notattand_patientslist') ?></header>
                            <?php $_POST = $users; ?>
                            <?php /*print_r($loginData); */?>
                            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                                data-mdl-for="panel-button">
                                
                                <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                                </li>
                            </ul>
                        </div>
                        <div class="card-body row">
                        <div class="table-responsive">
                                    <table
                                        class="table table-striped table-bordered table-hover table-checkable order-column"
                                        id="example4">
                                        <thead>
                                            <tr>
                                                <th class="center"><?php echo $this->lang->line('sr_no') ?></th>
                                                <th class="center"><?php echo $this->lang->line('patient_name') ?></th>
                                                <th class="center"><?php echo $this->lang->line('doctor_name') ?></th>
                                                <th class="center"><?php echo $this->lang->line('datetime') ?></th>
                                                <th class="center"><?php echo $this->lang->line('status') ?> </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(!empty($patientApp))
                                        {
                                            $sr=0;
                                            foreach($patientApp as $list)
                                            {
                                                $sr++;
                                                $patientData = $this->common_model->get_name(TBL_PATIENT,$list->patient_id);
                                                $doctorData = $this->common_model->get_name(TBL_DOCTOR,$list->doctor_id);
                                                ?>
                                                <tr>
                                                    <td class="center"><?= $sr;?></td>
                                                    <td class="center"><?= $patientData['name'];?></td>
                                                    <td class="center"><?= $doctorData['name'];?></td>
                                                    <td class="center"><?= $list->date_time;?></td>
                                                    <td class="center"><span class="label label-sm label-warning ">Not Attended</span>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        $sr++;
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            <div class="col-lg-12 p-t-20 text-center">
                                    <a href="<?php echo site_url('admin/users/index');?>"><button type="button" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 btn-circle btn-danger"><?php echo $this->lang->line('cancel') ?></button></a>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- end page content -->
        </form>
    </div>
    <!-- end page container -->
    <?php $this->load->view('layout/footer.php');?>