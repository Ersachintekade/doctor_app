<?php $this->load->view('layout/header.php');?>
<?php $this->load->view('layout/top_menu.php');?>   
    <!-- start page container -->
    <div class="page-container">
    <?php $this->load->view('layout/left_menu.php');?>   
        <!-- start page content -->
        <form action="<?php echo site_url('admin/users/setting');?>" method="post" enctype="multipart/form-data" >
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="page-bar">
                    <div class="page-title-breadcrumb">
                        <div class=" pull-left">
                            <div class="page-title">Dashboard</div>
                        </div>
                        <ol class="breadcrumb page-breadcrumb pull-right">
                            <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                                    href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                            </li>
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                <!-- start widget -->
                <div class="row">
                <?php if(!empty($this->session->flashdata('success_msg'))){ ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success !</strong> <?= $this->session->flashdata('success_msg');?>
                    </div> 
                <?php } ?>
                <?php if(!empty($this->session->flashdata('error_msg'))){ ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error !</strong> <?= $this->session->flashdata('error_msg');?>
                    </div>
                <?php } ?>
                </div> 
                <!-- end widget -->
                <div class="row">
                <div class="col-sm-12">
                    <div class="card-box">
                        <div class="card-head">
                            <header><?php echo $this->lang->line('doctor_details') ?></header>
                            <?php $_POST = $users; ?>
                            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                                data-mdl-for="panel-button">
                                <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                                </li>
                                <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                                </li>
                                <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                                    here</li>
                            </ul>
                        </div>
                        <div class="card-body ">
                            <div class="col-lg-6 p-t-20">
                                <div
                                    class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                    <input class="mdl-textfield__input" type="text" name="old_password" id="old_password" value="<?php echo set_value('password'); ?>" />
                                    <label class="mdl-textfield__label" for="error"><?php echo $this->lang->line('old_password') ?></label>
                                </div>
                                <label for="error" class="error"><?= form_error('old_password'); ?></label>
                            </div>
                            <div class="col-lg-6 p-t-20">
                                <div
                                    class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                    <input class="mdl-textfield__input" type="text" name="new_password" id="new_password" value="<?php echo set_value('password'); ?>" />
                                    <label class="mdl-textfield__label"><?php echo $this->lang->line('new_password') ?></label>
                                </div>
                                <label for="error" class="error"><?= form_error('new_password'); ?></label>
                            </div>
                            <div class="col-lg-6 p-t-20">
                                <div
                                    class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label txt-full-width">
                                    <input class="mdl-textfield__input" type="text" name="confirm_password" id="confirm_password" value="<?php echo set_value('password'); ?>" />
                                    <label class="mdl-textfield__label"><?php echo $this->lang->line('confirm_password') ?></label>
                                </div>
                                <label for="error" class="error"><?= form_error('confirm_password'); ?></label>
                            </div>
                            <div class="col-lg-12 p-t-20 text-center">
                                <button type="submit" name="submit" value="submit"
                                    class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 m-r-20 btn-circle btn-primary"><?php echo $this->lang->line('update') ?></button>
                                <!-- <button type="submit" name="save" value="Remove" >Cancel</button></a> -->
                               <a href="<?php echo site_url('admin/users/index');?>"><button type="button" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect m-b-10 btn-circle btn-danger"><?php echo $this->lang->line('cancel') ?></button></a>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- end page content -->
        </form>
    </div>
    <!-- end page container -->
     
    <?php $this->load->view('layout/footer.php');?>