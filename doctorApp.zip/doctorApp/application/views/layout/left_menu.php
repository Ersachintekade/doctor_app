<!-- start sidebar menu -->  
    <?php $loggedIn = $this->session->userdata("user_login");?>
    <div class="sidebar-container">
        <div class="sidemenu-container navbar-collapse collapse fixed-menu">
            <div id="remove-scroll" class="left-sidemenu">
                <ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false"
                    data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                    <li class="sidebar-toggler-wrapper hide">
                        <div class="sidebar-toggler">
                            <span></span>       
                        </div>
                    </li>
                    <li class="sidebar-user-panel">
                        <div class="sidebar-user">
                            <div class="sidebar-user-picture">
                                <img alt="image" src="<?= base_url();?>assets/img/user/<?= $loggedIn['image'];?>">
                            </div>
                            <div class="sidebar-user-details">
                                <div class="user-name"><?= $loggedIn['email'];?></div>
                                <div class="user-role"><?= $this->common_model->roleName($loggedIn['role_id']);?></div>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item start active open">
                        <a href="<?= site_url('admin/users/index');?>" class="nav-link nav-toggle">
                            <i data-feather="airplay"></i>
                            <span class="title"><?php echo $this->lang->line('dashboard') ?></span>
                            <span class="selected"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle">
                            <i data-feather="airplay"></i>
                            <span class="title"><?php echo $this->lang->line('configuration') ?></span>
                            <span class="arrow"></span>
                        </a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                            <a href="<?= site_url('admin/configuration/add');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('add_hospital_info') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                            <a href="<?= site_url('admin/configuration/index');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('hospital_details') ?></span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle"> <i data-feather="users"></i>
                            <span class="title"><?php echo $this->lang->line('patients') ?></span> <span class="arrow"></span>
                        </a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                                <a href="<?= site_url('admin/patients/index');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('all_patients') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?= site_url('admin/patients/add');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('add_patients') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?= site_url('admin/patients/appointment_form');?>" class="nav-link "> <span
                                        class="title"><?php echo $this->lang->line('appointment_form') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?= site_url('admin/patients/todays_patients');?>" class="nav-link "> <span
                                        class="title"><?php echo $this->lang->line('todays_patients') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?= site_url('admin/patients/register');?>" class="nav-link "> <span
                                        class="title">register</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle"><i data-feather="users"></i>
                            <span class="title"><?php echo $this->lang->line('doctors') ?></span><span class="arrow"></span></a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                            <a href="<?= site_url('admin/doctors/index');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('all_doctors') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                            <a href="<?= site_url('admin/doctors/add');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('add_doctors') ?></span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle"><i data-feather="users"></i>
                            <span class="title"><?php echo $this->lang->line('reports') ?></span><span class="arrow"></span></a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                            <a href="<?= site_url('admin/reports/all_report');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('all_reports') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                            <a href="<?= site_url('admin/reports/doctor_report');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('doctor_report') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                            <a href="<?= site_url('admin/reports/patient_report');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('patient_report') ?></span>
                                </a>
                            </li>
                        </ul>
                    </li> 
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle"><i class="material-icons f-left">receipt</i>
                            <span class="title"><?php echo $this->lang->line('bill') ?></span><span class="arrow"></span></a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                            <a href="<?= site_url('admin/bill/add_bill');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('add_bill') ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                            <a href="<?= site_url('admin/bill/fees_collection');?>" class="nav-link "> <span class="title"><?php echo $this->lang->line('fees_collection') ?></span>
                                </a>
                            </li>
                        </ul>
                    </li> 
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle"><i class="material-icons f-left">receipt</i>
                            <span class="title"><?php echo $this->lang->line('social_media') ?></span><span class="arrow"></span></a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                            <a href="<?= site_url('admin/patients/social_media');?>" class="nav-link "> <span class="title">Patient Details</span>
                                </a>
                            </li>
                        </ul>
                    </li> 
                </ul>
            </div>
        </div>
    </div>
<!-- end sidebar menu -->