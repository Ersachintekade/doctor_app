<?php $loggedIn = $this->session->userdata("user_login");?>
<!-- For language -->

<!-- start header -->
<div class="page-header navbar navbar-fixed-top">
        <div class="page-header-inner ">
            <!-- logo start -->
            <div class="page-logo">
                <a href="<?= site_url('admin/users/index');?>">
                    <span class="logo-icon material-icons fa-rotate-45">school</span>
                    <span class="logo-default">Cure-all</span></a>
                    
            </div>
            <!-- logo end -->
            <ul class="nav navbar-nav navbar-left in">
                <li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
            </ul>
            <!-- start mobile menu -->
            <a class="menu-toggler responsive-toggler" data-bs-toggle="collapse" data-bs-target=".navbar-collapse">
                <span></span>
            </a>
            <!-- end mobile menu -->
            <!-- start header menu -->
            <div class="top-menu">
                <ul class="nav navbar-nav pull-right">
                    <li><a class="fullscreen-btn"><i data-feather="maximize"></i></a></li>
                    <!-- start language menu -->
                    
                    <li class="dropdown language-switch">
                        <a class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"> <img
                                src="" class="position-left" alt=""><?php echo $this->lang->line('english') ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="lang" class="translate" href="<?php echo base_url("admin/users/switchLang/english"); ?>"><img src="" alt=""><?php echo $this->lang->line('english') ?></a>
                            </li>
                            <li>
                                <a class="lang" class="translate"href="<?php echo base_url("admin/users/switchLang/marathi"); ?>"><img src="" alt=""><?php echo $this->lang->line('marathi') ?></a>
                            </li>
                            <li>
                                <a class="lang" href="<?php echo base_url("admin/users/switchLang/hindi"); ?>" class="translate" ><img src="" alt=""><?php echo $this->lang->line('hindi') ?></a>
                            </li>
                        </ul>
                    </li>
                    <!-- end language menu -->
                    <!-- start notification dropdown -->
                    <?php $noticount = $this->common_model->all_count(TBL_APPOINTMENT,array('Date(date_time) >='=>date('Y-m-d'),'Date(date_time) <='=>date('Y-m-d'), "is_status"=>FALSE));?>
                    
                    <li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar">
                        <a class="dropdown-toggle" data-bs-toggle="dropdown" data-hover="dropdown"
                            data-close-others="true">
                            <i data-feather="bell"></i>
                            <span class="badge headerBadgeColor1"> <?= $noticount;?> </span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="external">
                                <h3><span class="bold"><?php echo $this->lang->line('notifications') ?></span></h3>
                                <span class="notification-label purple-bgcolor">New 
                                <?= $noticount;?>
                                </span>
                            </li>
                            <li>
                                <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                                    <?php
                                    $notiData = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array('Date(date_time) >='=>date('Y-m-d'),'Date(date_time) <='=>date('Y-m-d'), "is_status"=>FALSE));
                                    foreach($notiData as $noti)
                                    {
                                        $notiData = $this->common_model->get_name(TBL_PATIENT,$noti->patient_id);
                                        ?>
                                        <li>
                                            <a href="">
                                                
                                                <span class="time"><?php echo date('H:i',strtotime($noti->date_time));?></span>
                                                <span class="details">
                                                <span class="notification-icon circle deepPink-bgcolor">
                                                <i class="fa fa-check"></i></span>
                                                <?= $notiData['name'];?></span>
                                            </a>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                                <div class="dropdown-menu-footer">
                                    <a href="<?php echo site_url('admin/users/notification');?>"> All notifications </a>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <!-- end message dropdown -->
                    <!-- start manage user dropdown -->
                    <li class="dropdown dropdown-user">
                        <a class="dropdown-toggle" data-bs-toggle="dropdown" data-hover="dropdown"
                            data-close-others="true">
                            <img alt="user_pic" class="img-circle" src="<?= base_url();?>assets/img/user/<?= $loggedIn['image'];?>" />
                            <span class="username username-hide-on-mobile"><?= ucfirst($loggedIn['name']);?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-default">
                            <li>
                                <a href="<?php echo site_url('admin/users/profile');?>">
                                    <i class="icon-user"></i><?php echo $this->lang->line('profile') ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('admin/users/setting');?>">
                                    <i class="icon-settings"></i><?php echo $this->lang->line('settings') ?>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('admin/users/help');?>">
                                    <i class="icon-directions"></i><?php echo $this->lang->line('help') ?>
                                </a>
                            </li>
                            <li class="divider"> </li>
                            <li>
                                <a href="<?php echo site_url('admin/users/logout');?>">
                                    <i class="icon-logout"></i><?php echo $this->lang->line('logout') ?></a>
                            </li>
                        </ul>
                    </li>
                    <!-- end manage user dropdown -->
                </ul>
            </div>
        </div>
    </div>
    <!-- end header -->