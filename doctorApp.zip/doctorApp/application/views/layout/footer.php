
<!-- start footer -->
<div class="page-footer">
    <div class="page-footer-inner"> <?= date('Y');?> &copy; Tenaciousys IT Solutions By
        <a href="mailto:connect@tenaciousys.com" target="_top" class="makerCss">Doctor Application</a>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
</div>
</body>

<!-- end footer -->
<!-- end js include path -->
<script src="<?= base_url();?>assets/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url();?>assets/plugins/popper/popper.js"></script>
<script src="<?= base_url();?>assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="<?= base_url();?>assets/plugins/feather/feather.min.js"></script>
<script src="<?= base_url();?>assets/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- bootstrap -->
<script src="<?= base_url();?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url();?>assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="<?= base_url();?>assets/plugins/moment/moment.min.js"></script>
<!-- counterup -->
<script src="<?= base_url();?>assets/plugins/counterup/jquery.waypoints.min.js"></script>
<script src="<?= base_url();?>assets/plugins/counterup/jquery.counterup.min.js"></script>
<!-- Common js-->
<script src="<?= base_url();?>assets/js/app.js"></script>
<script src="<?= base_url();?>assets/js/layout.js"></script>
<script src="<?= base_url();?>assets/js/theme-color.js"></script>
<!-- Material -->
<script src="<?= base_url();?>assets/plugins/material/material.min.js"></script>
<script src="<?= base_url();?>assets/js/pages/material-select/getmdl-select.js"></script>
<script src="<?= base_url();?>assets/plugins/flatpicker/js/flatpicker.min.js"></script>
<script src="<?= base_url();?>assets/js/pages/date-time/date-time.init.js"></script>
<script src="<?= base_url();?>assets/plugins/sweet-alert/sweetalert2.all.min.js"></script>
<script src="<?= base_url();?>assets/plugins/sweet-alert/sweetalert2.min.js"></script>
<script src="<?= base_url();?>assets/js/patient.js"></script>
<!-- data tables -->
<script src="<?= base_url();?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url();?>assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap5.min.js"></script>
<script src="<?= base_url();?>assets/js/pages/table/table_data.js"></script>
<!--apex chart-->
<script src="<?= base_url();?>assets/plugins/apexcharts/apexcharts.min.js"></script>
<script src="<?= base_url();?>assets/js/pages/chart/apex/apexcharts.data.js"></script>
<!-- end js include path -->
</html>