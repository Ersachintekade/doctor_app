<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<meta name="description" content="Doctor Application" />
	<meta name="author" content="Tenaciousys it solutions" />
	<title>Doctor Application | All Work</title>
	<!-- google font -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet"
		type="text/css" />
	<!-- icons -->
	<link href="<?= base_url();?>assets/fonts/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url();?>assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url();?>assets/fonts/font-awesome/v6/css/all.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url();?>assets/fonts/material-design-icons/material-icon.css" rel="stylesheet" type="text/css" />
	<!--bootstrap -->
	<link href="<?= base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<!-- Material Design Lite CSS -->
	<link rel="stylesheet" href="<?= base_url();?>assets/plugins/material/material.min.css">
	<link rel="stylesheet" href="<?= base_url();?>assets/css/material_style.css">
	<!-- Theme Styles -->
	<link href="<?= base_url();?>assets/css/theme/light/theme_style.css" rel="stylesheet" id="rt_style_components" type="text/css" />
	<link href="<?= base_url();?>assets/css/plugins.min.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url();?>assets/css/theme/light/style.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url();?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url();?>assets/css/theme/light/theme-color.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url();?>assets/plugins/sweet-alert/sweetalert2.min.css" rel="stylesheet">
	<!-- Date Time item CSS -->
	<link rel="stylesheet" href="<?= base_url();?>assets/plugins/flatpicker/css/flatpickr.min.css" />
	<!-- favicon -->
	<link rel="shortcut icon" href="<?= base_url();?>https://www.einfosoft.com/templates/admin/smart/source/assets/img/favicon.ico" />
	<link href="<?= base_url();?>assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 
</html>
</head>
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">


