<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class configuration extends CI_Controller {
    /**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
    {
		$data = array();
		$result = $this->common_model->all_data(TBL_CONFIGURATION,'id','asc',array());
		if(!empty($result))
		{
		$data['configuration']=$result;
		}
      $this->load->view('admin/configuration/index',$data);
    }
    public function add()
    {
	$data = array();
	$code = $this->common_model->codeNo(TBL_CONFIGURATION,'CLINIC');

	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('clinic_name', 'Clinic Name', 'required',array('required' => 'You must Doctor Name.'));
	$this->form_validation->set_rules('owner_name', 'Owner Name', 'required',array('required' => 'You must City.'));
	$this->form_validation->set_rules('mobile_no', 'Mobile No', 'required',array('required' => 'You must Age.'));
	$this->form_validation->set_rules('email_id', 'Email Id', 'required',array('required' => 'You must Mobile Number.'));
	$this->form_validation->set_rules('address', 'Clinic Address', 'required',array('required' => 'You must Email Id.'));
	if (!empty($_FILES['image']['name'])){
	$config = array();
	$config['upload_path'] ='./assets/img/user';
	$config['allowed_types'] = 'gif|jpg|png|jpeg';
	$ext = pathinfo($_FILES["image"]['name'], PATHINFO_EXTENSION);
	$image = time().".".$ext;
	$config['file_name'] = $image;
	$this->upload->initialize($config);
	$this->load->library('upload', $config);
	if($this->upload->do_upload('image')){
	$upload_data = $this->upload->data();
	$image = $upload_data["file_name"];
	}
	else{
	$image = "";
	}
	}
	if ($this->form_validation->run() != FALSE)
	$ownerData = array( 
	'code'=> $code,
	'clinic_name'=> $this->input->post('clinic_name'),  
	'image'=> $image,  
	'owner_name'=> $this->input->post('owner_name'),
	'mobile_no'=> $this->input->post('mobile_no'),
	'email_id'=> $this->input->post('email_id'),
	'address'=> $this->input->post('address')
	);
	$userData = $this->common_model->create_data(TBL_CONFIGURATION,$ownerData);
	
	if(!empty($userData))
	{
	//session code
	$this->session->set_flashdata('success_msg','Owner Data added successfully.'); 
	redirect('admin/configuration/index');
	}else{
	$this->session->set_flashdata('error_msg','Please complete your field.');
	}
	}
      $this->load->view('admin/configuration/add',$data);
    }
    
	public function edit($id=null)
	{
	$data = array();
	$configuration = $this->common_model->get_data(TBL_CONFIGURATION,array("id ='".$id."'"));
	if(!empty($configuration)){
	$data['configuration']=$configuration;
	if(isset($_POST['submit']))
	{
	$id = $this->input->post('id');
	if (!empty($_FILES['image']['name'])){
	$config = array();
	$config['upload_path'] ='./assets/img/user/';
	$config['allowed_types'] = 'gif|jpg|png|jpeg';
	$ext = pathinfo($_FILES["image"]['name'], PATHINFO_EXTENSION);
	$image = time().".".$ext;
	$config['file_name'] = $image;
	$this->upload->initialize($config);
	$this->load->library('upload', $config);
	if($this->upload->do_upload('image')){
	$upload_data = $this->upload->data();
	$image = $upload_data["file_name"];
	unlink($config['upload_path'].''.$data['configuration']['image']);
	}
	else{
	$image = "";
	}
	}
	$ownerPost = array(  
		'clinic_name'=> $this->input->post('clinic_name'),  
		'image'=> $image,  
		'owner_name'=> $this->input->post('owner_name'),
		'mobile_no'=> $this->input->post('mobile_no'),
		'email_id'=> $this->input->post('email_id'),
		'address'=> $this->input->post('address')
	);
	$result = $this->common_model->update_data(TBL_CONFIGURATION,$ownerPost,array("id"=>$id));
	if($result)
	{
	$this->session->set_flashdata('success_msg','Doctor Data edited successfully.');
	redirect('admin/configuration/index');
	}else{
	$this->session->set_flashdata('error_msg','Doctor Data edited successfully.');
	redirect('admin/configuration/edit/'.$id);
	}
	}else{
	$_POST = $configuration;
	}
	}else{
	$this->session->set_flashdata('error_msg','Doctor Data not found.');
	redirect('admin/configuration/edit/'.$id);
	}
	$this->load->view('admin/configuration/edit',$data);
    }	


	public function delete($id=null)
	{
	$result = $this->common_model->delete_data(TBL_CONFIGURATION,array('is_deleted' =>true),array('id'=>$id)); 
	if($result)
	{
	$this->session->set_flashdata('success_msg','Doctor data deleted successfully.'); 
	redirect('admin/configuration/index');
	}else{
	$this->session->set_flashdata('error_msg','Please insert Doctor data .');
	redirect('admin/configuration/index');
	}
	} 
}
?>