<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
    /**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct()
    {
	parent::__construct();
	$allowedActions = array('login');
	$loggedIn = $this->session->userdata("user_login");
	$action = $this->router->fetch_method();
	if(!in_array($action,$allowedActions)){
	if(empty($loggedIn)){
	$this->session->set_flashdata('error_msg', 'Please login to your account');
	redirect('admin/users/login');
	}
    }
    }

	public function welcome()
	{
	$this->session->set_userdata('site_lang',  "english");
	$this->load->view('admin/users/welcome');
	}
	public function switchLang($language = "") {
	$this->session->set_userdata('site_lang', $language);
	redirect('admin/users/index');
	}

	public function register() {
		$username = $this->input->post('username');
        $password = $this->input->post('password');

        // Encrypt the password before storing it in the database
        $encrypted_password = $this->encryption->encrypt($password);

        // Call the model to insert user data into the database
        $this->user_model->register_user($username, $encrypted_password);
        $this->load->view('admin/users/register');
    }


	public function index()
	{
	$data = array();
	$doctorData = $this->common_model->all_data(TBL_DOCTOR,'id','asc',array());
	$result = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array( "is_status"=>FALSE));
	if(!empty($result)){
	$data['patientApp']=$result;
	$data['doctors']=$doctorData;
	}
	$this->load->view('admin/users/dashboard',$data);
	}

    public function login()
	{
	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('username', 'Username', 'required',array('required' => 'You must username.'));
	$this->form_validation->set_rules('password', 'Password', 'required',array('required' => 'You must password.'));
	if ($this->form_validation->run() != FALSE)
	{
	$username = $this->input->post('username');
	$password = $this->input->post('password');
	// $encrypted_email = $this->encryption->encrypt($username);
	// $encrypted_password = $this->encryption->encrypt($password);
	// print_r($encrypted_password);exit;
	// $dataPost = array(
	// 	"username" => $encrypted_email,
	// 	"password" => $encrypted_password
	// );
	$dataPost = array(
	"username ='".$username."'",
	"password ='".$password."'"
	);
	$getData = $this->common_model->get_data(TBL_USER,$dataPost);
	if(!empty($getData))
	{
	$this->session->set_userdata('user_login',$getData);
	//session code login users data
	$this->session->set_flashdata('success_msg','users successfully login.'); 
	redirect('admin/users/index');
	}else{
	$this->session->set_flashdata('error_msg','Username and Password not valid.');
	}
    }
	}
	$this->load->view('admin/users/login');
	}

	public function logout()
	{
	$loginData = $this->session->userdata('user_login');
	if(!empty($loginData))
	{
	$this->session->unset_userdata('user_login');
	$this->session->sess_destroy();
	redirect("admin/users/login"); 
	}
	}
	
	public function record_count() {
    $totalcount = $this->db_doctor->count_all(TBL_PATIENT);
    if($totalcount-> num_rows()>0)
	{
	return $totalcount->row();
	}else
	{
	return false;
	}
    }
	
	public function profile()
	{
	$data = array();
	$loggedIn = $this->session->userdata("user_login");
	$data['loginData'] = $loggedIn;
	if($loggedIn['role_id']==ROLE_ADMIN){
	$data['users'] = $this->common_model->get_data(TBL_USER,array("id ='".$loggedIn['id']."'"));
	}
	if($loggedIn['role_id']==ROLE_DOCTOR){
	$data['users'] = $this->common_model->get_data(TBL_DOCTOR,array("user_id ='".$loggedIn['id']."'"));
	}
	if(isset($_POST['submit']))
	{
	$id = $this->input->post('id');
	if($loggedIn['role_id']==ROLE_DOCTOR){
	$dPost = array(  
	'name'=> $this->input->post('name'),   
	'image'=> $image,  
	'mobile_no'=> $this->input->post('m_no'),
	);
	$result = $this->common_model->update_data(TBL_DOCTOR,$dPost,array("id"=>$id));
	}
	$uPost = array(  
	'name'=> $this->input->post('name'),   
	'image'=> $image,  
	'mobile_no'=> $this->input->post('m_no')
	);
	$result = $this->common_model->update_data(TBL_USER,$uPost,array("id"=>$loggedIn['id']));
	if($result)
	{
	$this->session->set_flashdata('success_msg','Doctor Data edited successfully.');
	redirect('admin/users/index'.$id);
	}else{
	$this->session->set_flashdata('error_msg','Doctor Data edited successfully.');
	redirect('admin/users/profile/'.$id);
	}
	}
	$this->load->view('admin/users/profile',$data);
    }

	public function setting(){
	$loggedIn = $this->session->userdata("user_login");
	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('old_password', 'Old Password', 'required',array('required' => 'You must enter old password.'));
	$this->form_validation->set_rules('new_password', 'New Password', 'required',array('required' => 'You must enter new password.'));
	$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required',array('required' => 'You must enter confirm password.'));
	if ($this->form_validation->run() != FALSE)
	{
	$oldPassword = $this->input->post('old_password');
	$newpassword = $this->input->post('new_password');
	$confirmpassword = $this->input->post('confirm_password');
	$oldpass = $this->common_model->get_data(TBL_USER,array("password ='".$oldPassword."'","id ='".$loggedIn['id']."'"));
	if(!empty($oldpass))
	{
	$dataPost = array(
	"password"=>$newpassword
	);
	if($newpassword==$confirmpassword){
	$resultPass = $this->common_model->update_data(TBL_USER,$dataPost,array("id"=>$loggedIn['id']));
	}else{
	$this->session->set_flashdata('error_msg','confirm password not matched.');
	}
	}else{
	$this->session->set_flashdata('error_msg','old password not matched.');
	}	
	}
	}
	$this->load->view('admin/users/setting');
	}

	public function help()
	{
	$data = array();
	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('name', 'Name', 'required',array('required' => 'Please enter Name.'));
	$this->form_validation->set_rules('mobile_no', 'Mobile No', 'required',array('required' => 'Please enter  Mobile Number.'));
	$this->form_validation->set_rules('email', 'Email Id', 'required',array('required' => 'Please enter Email Id.'));	
	$this->form_validation->set_rules('message', 'Message', 'required',array('required' => 'Please enter Message.'));
	if ($this->form_validation->run() != FALSE)
	{
	$contactPost = array(  
	'name'=> $this->input->post('name'),  
	'mobileno'=> $this->input->post('mobile_no'),
	'email'=> $this->input->post('email'),
	'message'=> $this->input->post('message'),
	);
	$userData = $this->common_model->create_data(TBL_CONTACT,$contactPost);
	if(!empty($userData))
	{
	$this->session->set_flashdata('success_msg','Message sent successfully.');
	redirect('admin/users/help');
	}else{
	$this->session->set_flashdata('error_msg','Message not sent successfully.');
	redirect('admin/users/help');
	}
	}
	}
	$this->load->view('admin/users/help',$data);
	}

	public function notification()
	{
	$data = array();
	$result = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array('Date(date_time)>=' => date('Y-m-d'),'Date(date_time) <='=>date('Y-m-d'), "is_status"=>FALSE));
	if(!empty($result)){
	$data['patientApp']=$result;
	$data['doctors']=$doctorData;
	}
	$this->load->view('admin/users/notification',$data);
	}

}
?>