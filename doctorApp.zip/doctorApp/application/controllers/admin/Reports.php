<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {
/**
 * Index Page for this controller.
 *
 * Maps to the following URL
 * 		http://example.com/index.php/welcome
 *	- or -
* 		http://example.com/index.php/welcome/index
*	- or -
* Since this controller is set as the default controller in
* config/routes.php, it's displayed at http://example.com/
*
* So any other public methods not prefixed with an underscore will
* map to /index.php/welcome/<method_name>
* @see https://codeigniter.com/userguide3/general/urls.html
*/

public function __construct()
	{
    parent::__construct();
    $allowedActions = array('login');
    $loggedIn = $this->session->userdata("user_login");
    $action = $this->router->fetch_method();
    if(!in_array($action,$allowedActions)){
    if(empty($loggedIn)){
    $this->session->set_flashdata('error_msg', 'Please login to your account');
    redirect('admin/users/login');
    }
    }
	}

    public function all_report($id=null)
	{
    $data = array();
    if(isset($_POST['submit']))
    {
    $this->form_validation->set_rules('from_date', 'From Date', 'required',array('required' => 'Please enter From Date.'));
    $this->form_validation->set_rules('to_date', 'To Date', 'required',array('required' => 'Please enter To Date.'));
	if ($this->form_validation->run() != FALSE)
    {
    $from_date = $this->input->post('from_date');
    $to_date = $this->input->post('to_date');
    $result = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array('Date(date_time) >='=>$from_date,'Date(date_time) <='=>$to_date));
    if(!empty($result)){
    $data['result']=$result;
    }
    if(!empty($insertData))
    {
    //session code
    $this->session->set_flashdata('success_msg','Appointment Form added successfully.'); 
    redirect('admin/reports/doctor_report');
    }else{
    $this->session->set_flashdata('error_msg','Please insert patient data .');
    }
    }
    }
    $this->load->view('admin/reports/all_report',$data);
    }
    
    public function doctor_report()
	{
    $data = array();
    $data['doctorLists'] = $this->common_model->data_dropdown(TBL_DOCTOR,array()); 
    if(isset($_POST['submit']))
    {
    $this->form_validation->set_rules('doctor_id', 'Select Report', 'required',array('required' => 'Please enter Select Doctor Name.'));
    $this->form_validation->set_rules('from_date', 'From Date', 'required',array('required' => 'Please enter From Date.'));
    $this->form_validation->set_rules('to_date', 'To Date', 'required',array('required' => 'Please enter To Date.'));
	if ($this->form_validation->run() != FALSE)
    {
    $from_date = $this->input->post('from_date');
    $to_date = $this->input->post('to_date');
    $doctor_id = $this->input->post('doctor_id');
    $result = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array('Date(date_time) >='=>$from_date,'Date(date_time) <='=>$to_date,'doctor_id'=>$doctor_id));
    if(!empty($result)){
    $data['result']=$result;
    }
    if(!empty($insertData))
    {
    //session code
    $this->session->set_flashdata('success_msg','Appointment Form added successfully.'); 
    redirect('admin/reports/doctor_report');
    }else{
    $this->session->set_flashdata('error_msg','Please insert patient data .');
    }
    }
    }  
    $this->load->view('admin/reports/doctor_report', $data);
    }

    public function patient_report()
    {
    $data = array();
    $data['patientLists'] = $this->common_model->data_dropdown(TBL_PATIENT,array());
    if(isset($_POST['submit']))
    {
    $this->form_validation->set_rules('patient_id', 'Select Report', 'required',array('required' => 'Please Select Patient Name.'));
    $this->form_validation->set_rules('from_date', 'From Date', 'required',array('required' => 'Please enter From Date.'));
    $this->form_validation->set_rules('to_date', 'To Date', 'required',array('required' => 'Please enter To Date.'));
    if ($this->form_validation->run() != FALSE)
    {
    $from_date = $this->input->post('from_date');
    $to_date = $this->input->post('to_date');
    $patient_id = $this->input->post('patient_id');
    $result = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array('Date(date_time) >='=>$from_date,'Date(date_time) <='=>$to_date,'patient_id'=>$patient_id));
    if(!empty($result)){
    $data['result']=$result;
    }
    if(!empty($insertData))
    {
    //session code
    $this->session->set_flashdata('success_msg','Appointment Form added successfully.'); 
    redirect('admin/reports/doctor_report');
    }else{
    $this->session->set_flashdata('error_msg','Please insert patient data .');
    }
    } 
    } 
    $this->load->view('admin/reports/patient_report', $data);
    }
    
}
?>