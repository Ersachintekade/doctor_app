<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doctors extends CI_Controller {
    /**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct()
	{
	parent::__construct();
	$allowedActions = array('login');
	$loggedIn = $this->session->userdata("user_login");
	$action = $this->router->fetch_method();
	if(!in_array($action,$allowedActions))
	{
	if(empty($loggedIn)){
	$this->session->set_flashdata('error_msg', 'Please login to your account');
	redirect('admin/users/login');
	}
	}
	}

	public function index()
	{
	$data = array();
	$result = $this->common_model->all_data(TBL_DOCTOR,'id','asc',array());
	if(!empty($result))
	{
	$data['doctors']=$result;
	}
	$this->load->view('admin/doctors/index',$data);
	}

	public function add()
	{
	$data = array();
	$code = $this->common_model->codeNo(TBL_DOCTOR,'TENAPA');
	$data['cliniclist'] = $this->common_model->data_dropdown(TBL_CONFIGURATION,array());
	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('doctor_name', 'Doctor Name', 'required',array('required' => 'You must Doctor Name.'));
	$this->form_validation->set_rules('designation', 'Designation', 'required',array('required' => 'You must Designation.'));
	$this->form_validation->set_rules('city', 'City', 'required',array('required' => 'You must City.'));
	$this->form_validation->set_rules('age', 'Age', 'required',array('required' => 'You must Age.'));
	$this->form_validation->set_rules('m_no', 'Mobile Number', 'required',array('required' => 'You must Mobile Number.'));
	$this->form_validation->set_rules('email', 'Email', 'required',array('required' => 'You must Email Id.'));
	if (!empty($_FILES['image']['name'])){
	$config = array();
	$config['upload_path'] ='./assets/img/user';
	$config['allowed_types'] = 'gif|jpg|png|jpeg';
	$ext = pathinfo($_FILES["image"]['name'], PATHINFO_EXTENSION);
	$image = time().".".$ext;
	$config['file_name'] = $image;
	$this->upload->initialize($config);
	$this->load->library('upload', $config);
	if($this->upload->do_upload('image')){
	$upload_data = $this->upload->data();
	$image = $upload_data["file_name"];
	}
	else{
	$image = "";
	}
	}
	if ($this->form_validation->run() != FALSE)
	$userPost = array(  
	'clinic_id'=> $this->input->post('clinic_id'),
	'name'=> $this->input->post('doctor_name'),  
	'image'=> $image,  
	'mobile_no'=> $this->input->post('m_no'),
	'username'=> $this->input->post('email'),
	'password'=> 'doctor@123',
	'role_id'=> ROLE_DOCTOR
	);
	$userData = $this->common_model->create_data(TBL_USER,$userPost);
	$dataPost = array(  
	'user_id'=>$userData,
	'name'=> $this->input->post('doctor_name'),  
	'code'=> $code, 
	'image'=> $image,  
	'designation'=> $this->input->post('designation'),
	'city'=> $this->input->post('city'),
	'age'=> $this->input->post('age'),
	'mobile_no'=> $this->input->post('m_no'),
	'email'=> $this->input->post('email')
	);
	$insertData = $this->common_model->create_data(TBL_DOCTOR,$dataPost);
	if(!empty($insertData))
	{
	//session code
	$this->session->set_flashdata('success_msg','Doctor Data added successfully.'); 
	redirect('admin/doctors/index');
	}else{
	$this->session->set_flashdata('error_msg','Please complte your field.');
	}
	}
	$this->load->view('admin/doctors/add',$data);
	}
	
	public function edit($id=null)
	{
	$data = array();
	$doctors = $this->common_model->get_data(TBL_DOCTOR,array("id ='".$id."'"));
	if(!empty($doctors)){
	$data['doctors']=$doctors;
	if(isset($_POST['submit']))
	{
	$id = $this->input->post('id');
	if (!empty($_FILES['image']['name'])){
	$config = array();
	$config['upload_path'] ='./assets/img/user/';
	$config['allowed_types'] = 'gif|jpg|png|jpeg';
	$ext = pathinfo($_FILES["image"]['name'], PATHINFO_EXTENSION);
	$image = time().".".$ext;
	$config['file_name'] = $image;
	$this->upload->initialize($config);
	$this->load->library('upload', $config);
	if($this->upload->do_upload('image')){
	$upload_data = $this->upload->data();
	$image = $upload_data["file_name"];
	unlink($config['upload_path'].''.$data['doctors']['image']);
	}
	else{
	$image = "";
	}
	}
	$dPost = array(  
	'name'=> $this->input->post('doctor_name'),   
	'image'=> $image,  
	'designation'=> $this->input->post('designation'),  
	'city'=> $this->input->post('city'),
	'age'=> $this->input->post('age'),
	'mobile_no'=> $this->input->post('m_no'),
	'email'=> $this->input->post('email')
	);
	$result = $this->common_model->update_data(TBL_DOCTOR,$dPost,array("id"=>$id));
	if($result)
	{
	$this->session->set_flashdata('success_msg','Doctor Data edited successfully.');
	redirect('admin/doctors/index');
	}else{
	$this->session->set_flashdata('error_msg','Doctor Data edited successfully.');
	redirect('admin/doctors/edit/'.$id);
	}
	}else{
	$_POST = $doctors;
	}
	}else{
	$this->session->set_flashdata('error_msg','Doctor Data not found.');
	redirect('admin/doctors/edit/'.$id);
	}
	$this->load->view('admin/doctors/edit',$data);
    }	

	public function delete($id=null)
	{
	$result = $this->common_model->delete_data(TBL_DOCTOR,array('is_deleted' =>true),array('id'=>$id)); 
	if($result)
	{
	$this->session->set_flashdata('success_msg','Doctor data deleted successfully.'); 
	redirect('admin/doctors/index');
	}else{
	$this->session->set_flashdata('error_msg','Please insert Doctor data .');
	redirect('admin/doctors/index');
	}
	} 

	public function view($id=null)
	{
	$data = array();
	$data['doctor'] = $this->common_model->get_data(TBL_DOCTOR,array("id ='".$id."'"));
	$data['doctorApp'] = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array("doctor_id" =>$id));
	$this->load->view('admin/doctors/view',$data);
	}

	public function d_Details()
	{
	$appointment = $this->common_model->all_data(TBL_APPOINTMENT,'id' ,'asc', array("doctor_id"=>$_POST['doctor_id']));
	$doctor_data = $this->common_model->get_data(TBL_DOCTOR,array("id ='".$_POST['doctor_id']."'"));
	echo json_encode(array('data'=>$appointment,'d_data'=>$doctor_data));
	}

	public function patientDetails()
	{
	$patient_data = $this->common_model->get_data(TBL_PATIENT,array("id ='".$_POST['id']."'"));
	echo json_encode(array('data'=>$patient_data));
	}
}
?>