<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patients extends CI_Controller {

/**
 * Index Page for this controller.
 *
 * Maps to the following URL
 * 		http://example.com/index.php/welcome
 *	- or -
* 		http://example.com/index.php/welcome/index
*	- or -
* Since this controller is set as the default controller in
* config/routes.php, it's displayed at http://example.com/
*
* So any other public methods not prefixed with an underscore will
* map to /index.php/welcome/<method_name>
* @see https://codeigniter.com/userguide3/general/urls.html
*/
    public function __construct()
	{
	parent::__construct();
	$allowedActions = array('login');
	$loggedIn = $this->session->userdata("user_login");
	$action = $this->router->fetch_method();
	if(!in_array($action,$allowedActions)){
	if(empty($loggedIn)){
	$this->session->set_flashdata('error_msg', 'Please login to your account');
	redirect('admin/users/login');
	}
	}
	}

	public function index()
	{
	$data = array();
	$result = $this->common_model->all_data(TBL_PATIENT,'id','asc',array());
	if(!empty($result)){
	$data['patients']=$result;
	}
	$this->load->view('admin/patients/index',$data);
	}

	public function add()
	{
	$data = array();
	$data['doctorLists'] = $this->common_model->data_dropdown(TBL_DOCTOR,array());
	$code = $this->common_model->codeNo(TBL_PATIENT,'TENAPA');
	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('patient_name', 'Patient Name', 'required',array('required' => 'Please enter Patient Name.'));
	$this->form_validation->set_rules('mobile_no', 'Mobile No', 'required',array('required' => 'Please enter Mobile No.'));
	$this->form_validation->set_rules('doctor_id', 'Select Doctor Name', 'required',array('required' => 'Please enter Doctor Name.'));
	$this->form_validation->set_rules('city', 'City', 'required',array('required' => 'Please enter  City.'));
	$this->form_validation->set_rules('age', 'Age', 'required',array('required' => 'Please enter Age.'));
	$this->form_validation->set_rules('date_time', 'Select Date &amp; Time', 'required',array('required' => 'Please enter  Date & time.'));
	$this->form_validation->set_rules('patient_description', 'Patient Description', 'required',array('required' => 'Please enter Patient Description.'));
	if ($this->form_validation->run() != FALSE)
	{
	$patients_data = $this->common_model->create_data(TBL_USER,$patientPost);
    $dataPost = array(  
	'user_id'=>$patients_data,
	'name'=> $this->input->post('patient_name'),  
	'code'=> $code, 
	'mobile_no'=> $this->input->post('mobile_no'),  
	'age'=> $this->input->post('age'),
	'city'=> $this->input->post('city'),
	'reg_date'=> date('Y-m-d',strtotime($this->input->post('date_time')))
	);
	$insertData = $this->common_model->create_data(TBL_PATIENT,$dataPost);
	if(!empty($insertData))
	{
	// appointment insert code 
	$apcode = $this->common_model->codeNo(TBL_PATIENT,'APPNT');
	$appData = array(
	"code"=> $apcode,
	"doctor_id"=>$this->input->post('doctor_id'),
	"patient_id"=>$insertData,
	"date_time"=>$this->input->post('date_time'),
	"patient_description"=>$this->input->post('patient_description'),
	);
	$insertApp = $this->common_model->create_data(TBL_APPOINTMENT,$appData);
	//session code
	$this->session->set_flashdata('success_msg','Patients Data added successfully.'); 
	redirect('admin/patients/index');
	}else{
	$this->session->set_flashdata('error_msg','Please insert patient data .');
	}
	}else{
	$this->session->set_flashdata('error_msg','Please complete your field.');
	}
	}
	$this->load->view('admin/patients/add',$data);
	}

	public function edit($id=null)
	{
	$data = array();
	$patients = $this->common_model->get_data(TBL_PATIENT,array("id ='".$id."'"));
	if(isset($_POST['submit']))
	{
	$id = $this->input->post('id');
	$dataPost = array(  
	'name' => $this->input->post('patient_name'),  
	'mobile_no' => $this->input->post('mobile_no'),  
	'age' => $this->input->post('age'),
	'city' => $this->input->post('city'),
	'reg_date' => $this->input->post('date_time')
	);
	$result = $this->common_model->update_data(TBL_PATIENT,$dataPost,array("id"=>$id));
    if($result)
	{
	$this->session->set_flashdata('success_msg','Patients Data added successfully.'); 
	redirect('admin/patients');
	}else{
		$this->session->set_flashdata('error_msg','Please insert patient data .');
	}
	}else{
	$_POST = $patients;
	}
	$this->load->view('admin/patients/edit',$data);
	}
		
    public function delete($id=null)
	{
	
	$result = $this->common_model->delete_data(TBL_PATIENT,array('is_deleted' =>true),array('id'=>$id)); 
	if($result)
	{
	$this->session->set_flashdata('success_msg','Patient data deleted successfully.'); 
	redirect('admin/patients/index');
	}else{
	redirect('admin/patients/index');
	}
	}      
         
	public function view($id=null)
	{
	$data = array();
	$data['patient'] = $this->common_model->get_data(TBL_PATIENT,array("id ='".$id."'"));
	$data['patientApp'] = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array("patient_id" =>$id));
	$nextDay = date("Y-m-d", time() + 86400);
	$result = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array('date_time >='=>date('Y-m-d'),'date_time <'=>$nextDay));
	if(!empty($result)){
	$data['patients']=$result;
	}
	$this->load->view('admin/patients/view',$data);
	}

	public function appointment_form()
	{
	$data = array();
	
	$data['doctorLists'] = $this->common_model->data_dropdown(TBL_DOCTOR,array());
	$data['patientLists'] = $this->common_model->data_dropdown(TBL_PATIENT,array());
	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('patient_id', 'Patient Name', 'required',array('required' => 'Please enter Patient Name.'));
	$this->form_validation->set_rules('doctor_id', 'Doctor Name', 'required',array('required' => 'Please enter Doctor Name.'));
	$this->form_validation->set_rules('date_time', 'Select Date &amp; Time', 'required',array('required' => 'Please enter Date&Time.'));	
	$this->form_validation->set_rules('patient_description', 'Patient Description', 'required',array('required' => 'Please enter Patient Description.'));
	if ($this->form_validation->run() != FALSE)
	{
	$apcode = $this->common_model->codeNo(TBL_APPOINTMENT,'APPNT');
	$dataPost = array(  
	"code"=> $apcode,
	'patient_id'=> $this->input->post('patient_id'),  
	'doctor_id'=> $this->input->post('doctor_id'),  
	'date_time'=> $this->input->post('date_time'), 
	'patient_description'=> $this->input->post('patient_description')
    );
	$insertData = $this->common_model->create_data(TBL_APPOINTMENT,$dataPost);
	if(!empty($insertData))
	{
	//session code
	$this->session->set_flashdata('success_msg','Appointment Form added successfully.'); 
	redirect('admin/patients/index');
	}else{
	$this->session->set_flashdata('error_msg','Please insert Patient Data .');
	}
	}else{
	$this->session->set_flashdata('error_msg','Please complete your field.');
	}
	}
	$this->load->view('admin/patients/appointment_form',$data);
	}

	public function appointment_ajax()
	{
	$data = array();
	$data['doctorLists'] = $this->common_model->data_dropdown(TBL_DOCTOR,array());
	$data['patientLists'] = $this->common_model->data_dropdown(TBL_PATIENT,array());
	if(isset($_POST['submit']))
	{
	$this->form_validation->set_rules('patient_id', 'Patient Name', 'required',array('required' => 'Please enter Patient Name.'));
	$this->form_validation->set_rules('doctor_id', 'Doctor Name', 'required',array('required' => 'Please enter Doctor Name.'));
	$this->form_validation->set_rules('date_time', 'Select Date &amp; Time', 'required',array('required' => 'Please enter Date&Time.'));	
	$this->form_validation->set_rules('patient_description', 'Patient Description', 'required',array('required' => 'Please enter Patient Description.'));
	if ($this->form_validation->run() != FALSE)
	{
	$dataPost = array(  
	'patient_id'=> $this->input->post('patient_id'),  
	'doctor_id'=> $this->input->post('doctor_id'),  
	'date_time'=> $this->input->post('date_time'), 
	'patient_description'=> $this->input->post('patient_description')
    );
	$insertData = $this->common_model->create_data(TBL_APPOINTMENT,$dataPost);
	if(!empty($insertData))
	{
	//session code
	$this->session->set_flashdata('success_msg','Appointment Form added successfully.'); 
	redirect('admin/patients/view/'.$this->input->post('patient_id'));
	}else{
	$this->session->set_flashdata('error_msg','Please insert patient data .');
	}
	}else{
	$this->session->set_flashdata('error_msg','Please complete your field.');
	}
    }
	// $this->load->view('admin/patients/appointment_form',$data);
	}

	public function todays_patients()
	{
	$data = array();
	$nextDay = date("Y-m-d", time() + 86400);
	$code = $this->common_model->codeNo(TBL_PATIENT,'TENAPA');
	$result = $this->common_model->all_data(TBL_APPOINTMENT,'id','asc',array('date_time >='=>date('Y-m-d'),'date_time <'=>$nextDay));
    if(!empty($result)){
	$data['patients']=$result;
	}
	$this->load->view('admin/patients/todays_patients',$data);
	}

	public function allDetails()
	{
	$patient = $this->common_model->get_data(TBL_APPOINTMENT,array("id ='".$_POST['id']."'"));
	echo json_encode(array('status'=>200,'data'=>$patient));
	}

	public function upDetails()
	{
	$result = $this->common_model->update_data(TBL_APPOINTMENT,array('doctor_description'=>$_POST['desc'],'is_status'=>true),array("id"=>$_POST['id']));
	$patient = $this->common_model->get_data(TBL_APPOINTMENT,array("id ='".$_POST['id']."'"));
	echo json_encode(array('status'=>200,'data'=>$result));
	}

	public function aboutDetails()
	{
	$appointment = $this->common_model->all_data(TBL_APPOINTMENT,'id' ,'asc', array("patient_id"=>$_POST['patient_id']));
	$patient_data = $this->common_model->get_data(TBL_PATIENT,array("id ='".$_POST['patient_id']."'"));
	echo json_encode(array('data'=>$appointment,'p_data'=>$patient_data));
	}

	public function doctorDetails()
	{
	$doctor_data = $this->common_model->get_data(TBL_DOCTOR,array("id ='".$_POST['id']."'"));
	echo json_encode(array('data'=>$doctor_data));
	}

	public function delete_d($id=null)
	{
	$results = $this->common_model->delete_data(TBL_APPOINTMENT,array('is_deleted' =>true),array('id'=>$id)); 
	$data = $this->common_model->get_data(TBL_APPOINTMENT,array('is_deleted' =>true,'id'=>$id));
	if($results)
	{
	$this->session->set_flashdata('success_msg','Patients data deleted successfully.'); 
	redirect('admin/patients/view/'.$data['patient_id']);
	}else{
	$this->session->set_flashdata('error_msg','Please insert patient data .');
	redirect('admin/patients/view/'.$data['patient_id']);
	}
	} 

	public function bookappointment(){
	$srt ='';
	$doctorLists = $this->common_model->data_dropdown(TBL_DOCTOR,array());
	foreach($doctorLists as $lists)
	{
	$srt .='<option value="'.$lists->id.'">'.$lists->name.'</option>';
	}
	$patientData = $this->common_model->get_data(TBL_PATIENT, array("id ='".$_POST['id']."'"));
	echo json_encode(array('doctorLists'=>$srt,'patientData'=>$patientData ));			
	}

	public function social_media()
	{
		$data = array();
		$result = $this->common_model->all_data(TBL_PATIENT,'id','asc',array());
		if(!empty($result)){
		$data['patients']=$result;
		}
	$this->load->view('admin/patients/social_media',$data);
	}
}  

?>
			