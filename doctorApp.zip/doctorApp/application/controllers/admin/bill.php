<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class bill extends CI_Controller {
    /**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */


     public function add_bill()
     {		
		
        $data = array();
        if(isset($_POST['submit']))
        {
        $this->form_validation->set_rules('appointment_code', 'Appointment Code', 'required',array('required' => 'Please enter From Date.'));
        if ($this->form_validation->run() != FALSE)
        {
            $dataPost = array("code ='".$this->input->post('appointment_code')."'");
            
        $result = $this->common_model->get_data(TBL_APPOINTMENT,$dataPost);
        //   print_r($result);
        //     exit;
        if(!empty($result))
        {
            $data['result']=$result;
        }else{
        $this->session->set_flashdata('error_msg','Please insert patient data .');
        }
        }
        }
    
	$this->load->view('admin/bill/add_bill',$data);
     }

     public function generate_bill()
     {
        // print_r($_POST);
        // exit;		
        $data = array();

        if(isset($_POST['submit']))
        {
        $this->form_validation->set_rules('fees_type', 'Fees Type', 'required',array('required' => 'Please enter From Date.'));
        $this->form_validation->set_rules('amount', 'Amount', 'required',array('required' => 'Please enter From Date.'));
        $this->form_validation->set_rules('collection_date', 'Collection Date', 'required',array('required' => 'Please enter From Date.'));
        $this->form_validation->set_rules('payment_method', 'Payment Method', 'required',array('required' => 'Please enter From Date.'));
        $this->form_validation->set_rules('reference_name', 'Reference Name', 'required',array('required' => 'Please enter From Date.'));
        $this->form_validation->set_rules('payment_status', 'Payment Status', 'required',array('required' => 'Please enter From Date.'));
        $this->form_validation->set_rules('payment_details', 'Payment Details', 'required',array('required' => 'Please enter From Date.'));
        if ($this->form_validation->run() != FALSE)
        {
            $code = $this->common_model->codeNo(TBL_BILL,'INVOICE');

            $billPost = array( 
                'code' => $code, 
                'appointment_id' => $this->input->post('appointment_id'),
                'fees_type'=> $this->input->post('fees_type'),
                'amount'=> $this->input->post('amount'),  
                'collection_date'=> $this->input->post('collection_date'),
                'payment_method'=> $this->input->post('payment_method'),
                'reference_name'=> $this->input->post('reference_name'),
                'payment_status'=>$this->input->post('payment_status'),
                'payment_details'=> $this->input->post('payment_details')
                );  
            // print_r($billPost);
            // exit;
        $result = $this->common_model->create_data(TBL_BILL,$billPost);
        if(!empty($result))
        {
            // print_r($billPost);
            // exit;
    $this->session->set_flashdata('success_msg','Bill added successfully.'); 
	redirect('admin/bill/fees_collection');
	}
	}else{
	$this->session->set_flashdata('error_msg','Please complete your field.');
    redirect('admin/bill/add_bill');
	}
    }
    $this->load->view('admin/bill/fees_collection',$data);
    }

	 public function fees_collection($id=null)
     {
        
        $data = array();
	    // $data['patients'] = $this->common_model->all_data(TBL_APPOINTMENT,array("id ='".$id."'"));
	    $data['result'] = $this->common_model->all_data(TBL_BILL,'id','asc',array());
        // print_r($result);
        // exit;
        $this->load->view('admin/bill/fees_collection', $data);
        
     }

	 public function fee_receipt($id=null)
     {
        $data = array();
        $result= $this->common_model->get_data(TBL_BILL,array("id ='".$id."'"));
        if(!empty($result)){
        $data['result']=$result;
        }
       $this->load->view('admin/bill/fee_receipt',$data);
     }
}
?>