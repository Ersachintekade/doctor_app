<?php  
defined('BASEPATH') OR exit('No direct script access allowed'); 
 
// Include Rest Controller library 
require APPPATH . '/libraries/REST_Controller.php'; 

class Api extends REST_Controller { 
    public function __construct() {  
        parent::__construct(); 
    }
    public function users_get($id = null) { 
        // Returns all rows if the id parameter doesn't exist, 
        //otherwise single row will be returned 
        if(!empty($id)){
            $users = $this->common_model->get_data('tbl_users',array("id ='".$id."'"));
        }else{
            $users = $this->common_model->all_data('tbl_users','id','asc',array());
        }
        //check if the user data exists 
        if(!empty($users)){ 
            // Set the response and exit 
            //OK (200) being the HTTP response code 
            $this->response($users, REST_Controller::HTTP_OK); 
        }else{ 
            // Set the response and exit 
            //NOT_FOUND (404) being the HTTP response code 
            $this->response([ 
                'status' => FALSE, 
                'message' => 'No users were found.' 
            ], REST_Controller::HTTP_NOT_FOUND); 
        } 
    }
     

    public function users_post()
    {
        // $this->some_model->update_user( ... );
        $userData = array(
            'role_id' => $this->post('role_id'),
            'clinic_id' => $this->post('clinic_id'),
            'name' => $this->post('name'),
            'mobile_no' => $this->post('mobile_no'),
            'designation' => $this->post('designation'),
            'username' => $this->post('username'),
            'password' => $this->post('password'),
            'image' => 'gh',
        );

        if(!empty($userData['role_id']) && !empty($userData['clinic_id'])){ 
            // Insert user record in database 
            $insert = $this->common_model->create_data('tbl_users',$userData); 
             
            // Check if the user data inserted 
            if($insert){ 
                // Set the response and exit 
                $this->response([ 
                    'status' => TRUE, 
                    'message' => 'User has been added successfully.' 
                ], REST_Controller::HTTP_OK); 
            }else{ 
                // Set the response and exit 
                $this->response("Something went wrong, please try again.", REST_Controller::HTTP_BAD_REQUEST); 
            } 
        }else{ 
            // Set the response and exit 
            //BAD_REQUEST (400) being the HTTP response code 
            $this->response("Provide complete user information to create.", REST_Controller::HTTP_BAD_REQUEST); 
        }
    }

    public function users_put() { 
        $id = $this->put('id'); 
        if(!empty($id)){ 
            $userData = array(); 
            if(!empty($this->put('role_id'))){ 
                $userData['role_id'] = $this->put('role_id'); 
            } 
            if(!empty($this->put('clinic_id'))){ 
                $userData['clinic_id'] = $this->put('clinic_id'); 
            } 
            if(!empty($this->put('name'))){ 
                $userData['name'] = $this->put('name'); 
            } 
            if(!empty($this->put('mobile_no'))){ 
                $userData['mobile_no'] = $this->put('mobile_no'); 
            } 
            if(!empty($this->put('designation'))){ 
                $userData['designation'] = $this->put('designation'); 
            } 
            if(!empty($this->put('username'))){ 
                $userData['username'] = $this->put('username'); 
            } 
            if(!empty($this->put('password'))){ 
                $userData['password'] = $this->put('password'); 
            } 
           
 
            if(!empty($userData)){ 
                // Update user record in database 
                $update = $this->common_model->update_data('tbl_users',$userData, array("id ='".$id."'")); 
 
                // Check if the user data updated 
                if($update){ 
                    // Set the response and exit 
                    $this->response([ 
                        'status' => TRUE, 
                        'message' => 'User has been updated successfully.' 
                    ], REST_Controller::HTTP_OK); 
                }else{ 
                    // Set the response and exit 
                    $this->response("Something went wrong, please try again.", REST_Controller::HTTP_BAD_REQUEST); 
                } 
            }else{ 
                $this->response("Provide user information to update.", REST_Controller::HTTP_BAD_REQUEST); 
            } 
        }else{ 
            // Set the response and exit 
            $this->response("Provide the reference ID of the user to be updated.", REST_Controller::HTTP_BAD_REQUEST); 
        } 
    } 

    public function users_delete($id){ 
        // Check whether user ID is not empty 
        if($id){ 
            // Delete user record from database 
            $delete = $this->common_model->delete_data('tbl_users',array('is_deleted' =>true),array('id'=>$id)); 
             
            if($delete){ 
                // Set the response and exit 
                $this->response([ 
                    'status' => TRUE, 
                    'message' => 'User has been removed successfully.' 
                ], REST_Controller::HTTP_OK); 
            }else{ 
                // Set the response and exit 
                $this->response("Something went wrong, please try again.", REST_Controller::HTTP_BAD_REQUEST); 
            } 
        }else{ 
            // Set the response and exit 
            $this->response([ 
                'status' => FALSE, 
                'message' => 'No users were found.' 
            ], REST_Controller::HTTP_NOT_FOUND); 
        } 
    }   

// Patients API

    public function patients_get($id = null) { 
        // Returns all rows if the id parameter doesn't exist, 
        //otherwise single row will be returned 
        if(!empty($id)){
            $patients = $this->common_model->get_data('tbl_patients',array("id ='".$id."'"));
        }else{
            $patients = $this->common_model->all_data('tbl_patients','id','asc',array());
        }
        //check if the user data exists 
        if(!empty($patients)){ 
            // Set the response and exit 
            //OK (200) being the HTTP response code 
            $this->response($patients, REST_Controller::HTTP_OK); 
        }else{ 
            // Set the response and exit 
            //NOT_FOUND (404) being the HTTP response code 
            $this->response([ 
                'status' => FALSE, 
                'message' => 'No users were found.' 
            ], REST_Controller::HTTP_NOT_FOUND); 
        } 
    }
     
    public function patients_post()
    {
        // $this->some_model->update_user( ... );
        $patientsData = array(
            'name' => $this->post('name'),
            'mobile_no' => $this->post('mobile_no'),
            'city' => $this->post('city'),
            'age' => $this->post('age'),
            'patient_description' => $this->post('patient_description'),
            'reg_date' => date('Y-m-d',strtotime($this->input->post('date_time'))),
        );
        // print_r($patientsData);
        // exit;
        if(!empty($patientsData)){ 
            // Insert user record in database 
            $insert = $this->common_model->create_data('tbl_patients',$patientsData); 
             
            
            // Check if the user data inserted 
            if($insert){ 
                // Set the response and exit 
                $this->response([ 
                    'status' => TRUE, 
                    'message' => 'User has been added successfully.' 
                ], REST_Controller::HTTP_OK); 
            }else{ 
                // Set the response and exit 
                $this->response("Something went wrong, please try again.", REST_Controller::HTTP_BAD_REQUEST); 
            } 
        }else{ 
            // Set the response and exit 
            //BAD_REQUEST (400) being the HTTP response code 
            $this->response("Provide complete user information to create.", REST_Controller::HTTP_BAD_REQUEST); 
        }
    }

}