<?php
class Common_model extends CI_Model 
{
function __construct() {
parent::__construct();
}



// public function register_user($username, $password) {
//     $data = array(
//         'username' => $username,
//         'password' => $password
//     );
//     $this->db->insert('tbl_users', $data); // 'users' is the name of your users table
// }

function all_data($tblname,$col,$dir,$conds=array())
{
if(!empty($conds)){
$this
->db
->where($conds);
}
$query = $this
->db
->select('*')
->where(array("is_deleted"=>false))
->order_by($col,$dir)
->get($tblname);
	// print_r($this->db->last_query());exit;
if($query->num_rows()>0)
{
    return $query->result(); 
}
else
{
    return null;
}
}

public function create_data($tblname,$data) {
if(!empty($data)){
$this->db->insert($tblname, $data);
//print_r($this->db->last_query());exit;
return $this->db->insert_id();
}
return false;
}

public function update_data($tblname,$data=array(),$where=array()) {
if(!empty($data) and !empty($where)){
$this->db->where($where);
return $this->db->update($tblname, $data);
}
return false;
}
    
public function get_data($tblname, $cond=array())
{
$str_cond = '';
if(!empty($cond)){
$str_cond = " WHERE ".implode(" AND ",$cond)." ";
$query = $this->db->query("SELECT * FROM ".$tblname." ".$str_cond." LIMIT 1");
if(!empty($query)){
    return $query->row_array();
}            
}
return false;
}

public function get_name($tblname, $id)
{
$query = $this->db->query("SELECT * FROM ".$tblname." WHERE id =".$id." LIMIT 1");
if(!empty($query)){
return $query->row_array();
}            
}

public function delete_data($tblname,$data=array(),$where=array()){
if(!empty($data) and !empty($where)){
$this->db->where($where);
return $this->db->update($tblname, $data);
}
return false;
}

function data_dropdown($tblname,$conds=array())
{
if(!empty($conds)){
$this
->db
->where($conds);
}
$query = $this
->db
->where(array("is_deleted"=>false))
->order_by("id","ASC")
->get($tblname);
if(!empty($query)){
if($query->num_rows()>0)
{
    return $query->result(); 
}
else
{
    return null;
}
}
}

public function codeNo($tblname,$pre){
$query = $this->db->query("SELECT code FROM ".$tblname." order by id desc LIMIT 1");
if(!empty($list = $query->row_array())){
$exp_order = explode("-",$list['code']);
$order_no = trim($exp_order[1]);
$no = $order_no + 1;
}
else{
$no = 1;
}
return $pre."-".sprintf("%05d", $no);
}

public function roleName($id)
{
$arr = ["1"=>"Administor","2"=>"Doctor","3"=>"Paisent"];
return $arr[$id];
}

function all_count($tblname,$conds=array())
{
if(!empty($conds)){
$this
->db
->where($conds);
}
$query = $this
->db
->select('*')
// ->where(array("is_deleted"=>false))
->get($tblname);
//print_r($this->db->last_query());exit;
return $query->num_rows();
}    
}
?>